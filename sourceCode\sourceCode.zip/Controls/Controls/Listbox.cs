/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Listbox : Control
    {

        #region Variables

        private Color _bkg = Colors.LightGray;
        private ArrayList _items = new ArrayList();
        private int _selIndex = -1;
        private int _scrollY = 0;
        private int _mY = 0;
        private bool _bMoved = false;

        #endregion

        #region Contructors

        public Listbox(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public Listbox(int x, int y, int width, int height, string[] items)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            for (int i = 0; i < items.Length; i++)
            {
                _items.Add(items[i]);
            }
            if (items != null) _selIndex = 0;
        }

        #endregion

        #region Touch Invokes

        public override void TouchDown(object sender, point e)
        {
            _mY = e.Y;
            _mDown = true;
        }

        public override void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (_bMoved)
                {
                    _bMoved = false;
                }
                else
                {
                    if (this.ScreenBounds.contains(e))
                    {
                        int y = e.Y - Top + -(_scrollY);
                        int index = 0;
                        while (y > 32)
                        {
                            y -= 32;
                            index++;
                        }
                        if (index <= _items.Count)
                        {
                            SelectedIndex = index;
                        }

                        OnTap(this, new point(e.X - Left, e.Y - Top));
                    }
                }
                _mDown = false;
            }
        }

        public override void TouchMove(object sender, point e)
        {
            int nScroll = _scrollY + (e.Y - _mY);
            if (nScroll > 0) nScroll = 0;
            if (nScroll < -(_items.Count * 32) + _h - 2) nScroll = -(_items.Count * 32) + _h - 2;
            _mY = e.Y;
            _bMoved = true;
            if (_scrollY != nScroll)
            {
                _scrollY = nScroll;
                Render(true);
            }
        }

        #endregion

        #region  Properties

        public int Length
        {
            get { return _items.Count; }
        }

        public int SelectedIndex
        {
            get { return _selIndex; }
            set
            {
                if (_selIndex == value) return;
                _selIndex = value;
                Render(true);
                OnSelectedIndexChange(this, value);
            }
        }

        public string SelectedItem
        {
            get { return (string)_items[_selIndex]; }
        }

        public override int Height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        #endregion

        #region Events

        public event OnSelectedIndexChange SelectedIndexChanged;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnSelectedIndexChange(Object sender, int e)
        {
            if (SelectedIndexChanged != null) SelectedIndexChanged(sender, e);
        }

        #endregion

        #region Public Methods

        public void AddItem(string text)
        {
            _items.Add(text);
            if (_selIndex < 0)
            {
                SelectedIndex = 0;
            }
            else
                Render(true);
        }

        public void Clear()
        {
            _items.Clear();
            SelectedIndex = -1;
        }

        public void RemoveItem(string text)
        {
            _items.Remove(text);
            if (_selIndex > _items.Count) SelectedIndex = _items.Count - 1;
            Render(true);
        }

        public void RemoveItemAt(int index)
        {
            _items.RemoveAt(index);
            if (_selIndex > _items.Count)
            {
                SelectedIndex = _items.Count - 1;
            }
            else
                Render(true);
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (!_visible || _parent == null || _parent.ScreenBuffer == null || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            _parent.ScreenBuffer.DrawRectangle(Color.Black, 1, Left, Top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);

            int totalH = _items.Count * 32;
            int wOffset = 0;
            int y = _scrollY + Top + 1;
            bool bScroll = false;

            rect Region = rect.intersect(new rect(_parent.Left, _parent.Top, _parent.Width, _parent.Height), new rect(Left + 1, Top + 1, _w - 2, _h - 2));
            _parent.ScreenBuffer.SetClippingRectangle(Region.X, Region.Y, Region.Width, Region.Height);

            if (totalH > _h)
            {
                wOffset = 8;
                bScroll = true;
            }

            for (int i = 0; i < _items.Count; i++)
            {
                if (y > -32)
                {
                    _parent.ScreenBuffer.DrawRectangle(Color.White, 1, Left + 1, y, _w - 2, 32, 0, 0, Color.White, 0, 0, Color.White, 0, 0, 256);

                    if (i < _items.Count - 1)
                        _parent.ScreenBuffer.DrawLine(Colors.LightGray, 1, Left + 5, y + 31, Left + _w - 10 - wOffset, y + 31);

                    _parent.ScreenBuffer.DrawEllipse((_enabled) ? Colors.Gray : Colors.DarkGray, 1, Left + 16, y + 15, 9, 9, (_enabled) ? Colors.White : Colors.Gray, 0, 0, (_enabled) ? Colors.White : Colors.Gray, 0, 0, 255);
                    _parent.ScreenBuffer.DrawEllipse((i == _selIndex) ? ColorUtility.ColorFromRGB(117, 184, 2) : ColorUtility.ColorFromRGB(156, 156, 156), 1, Left + 16, y + 15, 5, 5, (i == _selIndex) ? ColorUtility.ColorFromRGB(190, 253, 80) : ColorUtility.ColorFromRGB(210, 210, 210), 0, 0, (_enabled) ? Color.White : Colors.Gray, 0, 0, 255);

                    _parent.ScreenBuffer.DrawTextInRect((string)_items[i], Left + 42, y + 9, _w - 33 - wOffset, 20, Bitmap.DT_AlignmentLeft + Bitmap.DT_TrimmingCharacterEllipsis, Color.Black, FontManager.Arial);
                }

                y += 32;

                if (y >= Top + Height)
                    break;
            }

            if (bScroll)
            {
                _parent.ScreenBuffer.DrawRectangle(Colors.DarkGray, 1, Left + _w - 9, Top + 1, 9, _h - 2, 0, 0, Colors.DarkGray, 0, 0, Colors.DarkGray, 0, 0, 256);

                float sH = (float)(totalH - _h);
                float sY = (sH == 0) ? 0 : -((float)_scrollY) / (float)(totalH - _h);
                int iSY = (int)((float)(_h - 24) * sY);
                _parent.ScreenBuffer.DrawRectangle(Colors.LightGray, 1, Left + _w - 9, Top + 1 + iSY, 9, 20, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            }

            if (flush)
            {
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
            }
        }

        #endregion

    }
}
