/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;
using Skewworks.Pyxis.EXT;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class CommandButton : Control
    {

        #region Variables

        private string _text = "";
        private Font _font = FontManager.Arial;
        private Color _color = Color.Black;
        private PressedState _pressed = PressedState.Normal;

        #endregion

        #region Constructors

        public CommandButton(string text, int x, int y)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = 75;
            _h = 25;
        }

        public CommandButton(string text, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public CommandButton(string text, Font font, Color ForeColor, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _font = font;
            _color = ForeColor;
        }

        #endregion

        #region Touch Invokes

        public override void TouchDown(object sender, point e)
        {
            _mDown = true;
            if (_enabled)
            {
                _pressed = PressedState.Pressed;
                Render(true);
            }
        }

        public override void TouchUp(object sender, point e)
        {
            if (_pressed == PressedState.Pressed && _enabled)
            {
                _pressed = PressedState.Normal;
                Render(true);
                if (_mDown)
                {
                    if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.X - Left, e.Y - Top));
                    _mDown = false;
                }
            }
        }

        #endregion

        #region  Properties

        public string Text
        {
            get { return _text; }
            set { _text = value; Render(true); }
        }

        public Font Font
        {
            get { return _font; }
            set { _font = value; Render(true); }
        }

        public Color Color
        {
            get { return _color; }
            set { _color = value; Render(true); }
        }

        public override int Height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }
        
        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            Color back1 = ColorUtility.ColorFromRGB(242, 242, 242);
            Color back2 = ColorUtility.ColorFromRGB(207, 207, 207);

            //// Draw Border & Background
            _parent.ScreenBuffer.DrawRectangle(ColorUtility.ColorFromRGB(112, 112, 112), 1, Left, Top, _w, _h, 1, 1, Color.Black, 0, 0, Color.Black, 0, 0, 0);
            _parent.ScreenBuffer.DrawRectangle(Color.White, 1, Left + 1, Top + 1, _w - 2, _h - 2, 0, 0, (_pressed == PressedState.Normal) ? back1 : back2, 0, 0, (_pressed == PressedState.Normal) ? back1 : back2, 0, 0, 256);
            _parent.ScreenBuffer.DrawRectangle(Color.White, 0, Left + 2, Top + (_h / 2), _w - 4, (_h / 2) - 1, 0, 0, (_pressed == PressedState.Normal) ? back2 : back1, 0, 0, (_pressed == PressedState.Normal) ? back2 : back1, 0, 0, 256);


            _parent.ScreenBuffer.DrawTextInRect(_text, Left + 3, Top + 4, _w - 6, _h - 8, Bitmap.DT_AlignmentCenter + Bitmap.DT_TrimmingNone, (_enabled) ? _color : Colors.DarkGray, _font);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

    }
}
