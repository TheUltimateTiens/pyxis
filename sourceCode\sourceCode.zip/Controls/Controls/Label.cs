/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Label : Control
    {

        #region Variables

        private string _text = "";
        private bool _autosize = true;
        private Font _font = FontManager.Arial;
        private Color _color = Color.Black;

        #endregion

        #region Constructors

        public Label(string text, int x, int y)
        {
            _text = text;
            _x = x;
            _y = y;
        }

        public Label(string text, Font font, int x, int y)
        {
            _font = font;
            _text = text;
            _x = x;
            _y = y;
        }

        public Label(string text, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _autosize = false;
        }

        public Label(string text, Color ForeColor, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _autosize = false;
        }

        public Label(string text, Color ForeColor, Font font, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _font = font;
            _autosize = false;
        }

        public Label(string text, Color ForeColor, Font font, int x, int y, int width, int height, bool enabled, bool visible)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _font = font;
            _autosize = false;
            _visible = visible;
            _enabled = enabled;
        }

        #endregion

        #region  Properties

        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                if (_autosize)
                {
                    if (_parent != null) _parent.Render();
                }
                else
                {
                    Render(true);
                }
            }
        }

        public bool AutoSize
        {
            get { return _autosize; }
            set
            {
                _autosize = value;
                if (_parent != null) _parent.Render();
            }
        }

        public Font Font
        {
            get { return _font; }
            set
            {
                _font = value;
                if (_autosize)
                {
                    if (_parent != null) _parent.Render();
                }
                else
                {
                    Render(true);
                }
            }
        }

        public Color Color
        {
            get { return _color; }
            set
            {
                _color = value;
                Render(true);
            }
        }
        
        public override int Height
        {
            get { return _h; }
            set
            {
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        #endregion
        
        #region GUI

        public override void Render(bool flush)
        {
            int w = _w;
            int h = _h;

            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            // Auto-Size first
            if (_autosize) _font.ComputeExtent(_text, out w, out h);

            // Draw String
            _parent.ScreenBuffer.DrawTextInRect(_text, Left, Top, w, h, Bitmap.DT_AlignmentLeft + Bitmap.DT_WordWrap, _color, _font);

            // Flush if needed
            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

    }
}
