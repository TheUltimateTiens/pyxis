/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Progressbar : Control
    {

        #region Variables
        
        private int _min = 0;
        private int _max = 100;
        private int _val = 0;

        #endregion

        #region Constructors

        public Progressbar(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public Progressbar(int x, int y, int width, int height, int minvalue, int maxvalue, int value)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _min = minvalue;
            _max = maxvalue;
            _val = value;
        }

        #endregion

        #region  Properties

        public int Minimum
        {
            get { return _min; }
            set
            {
                if (value >= _max) value = _max - 1;
                _min = value;
                Render(true);
            }
        }

        public int Maximum
        {
            get { return _max; }
            set
            {
                if (value <= _min) value = _min + 1;
                _max = value;
                Render(true);
            }
        }

        public int Value
        {
            get { return _val; }
            set
            {
                if (value < _min) value = _min;
                if (value > _max) value = _max;
                _val = value;
                Render(true);
            }
        }
        
        public override int Height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            Color Border = ColorUtility.ColorFromRGB(161, 161, 161);
            Color Bkg = ColorUtility.ColorFromRGB(227, 227, 227);
            Color BkgDark = ColorUtility.ColorFromRGB(210, 210, 210);
            Color BkgLight = ColorUtility.ColorFromRGB(244, 244, 244);
            Color Fill = ColorUtility.ColorFromRGB(149, 193, 252);
            Color ValLight = ColorUtility.ColorFromRGB(228, 236, 241);
            Color ValDark = ColorUtility.ColorFromRGB(114, 159, 219);

            // Draw Border & Background
            _parent.ScreenBuffer.DrawRectangle(Border, 1, Left, Top, _w, _h, 0, 0, Bkg, 0, 0, Bkg, 0, 0, 256);
            _parent.ScreenBuffer.DrawLine(BkgLight, 1, Left + 1, Top + _h - 2, Left + _w - 2, Top + _h - 2);
            _parent.ScreenBuffer.DrawLine(BkgDark, 1, Left + 1, Top + 1, Left + _w - 2, Top + 1);

            // Figure out progress fill
            if (_val == _min) return;
            int rng = _max - _min;
            int val = _val - _min;
            float prc = ((float)val / (float)rng);
            int wid = (int)((float)(_w - 2) * prc);
            if (wid < 1) return;

            // Draw progress fill
            _parent.ScreenBuffer.DrawRectangle(Fill, 0, Left + 1, Top + 1, wid, _h - 2, 0, 0, Fill, 0, 0, Fill, 0, 0, 256);
            if (wid > 2) _parent.ScreenBuffer.DrawLine(ValLight, 1, Left + 2, Top + _h - 2, Left + wid - 1, Top + _h - 2);
            if (wid > 2) _parent.ScreenBuffer.DrawLine(ValDark, 1, Left + 2, Top + 1, Left + wid - 1, Top + 1);
            _parent.ScreenBuffer.DrawLine(ValDark, 1, Left + wid, Top + 1, Left + wid, Top + _h - 2);
            _parent.ScreenBuffer.DrawLine(ValLight, 1, Left + 1, Top + 1, Left + 1, Top + _h - 2);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

    }
}
