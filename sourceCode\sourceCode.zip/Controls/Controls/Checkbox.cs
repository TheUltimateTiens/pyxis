/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Checkbox : Control
    {

        #region Variables

        private bool _checked = false;

        #endregion

        #region Constructors

        public Checkbox(int x, int y)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
        }

        public Checkbox(int x, int y, bool selected)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
            _checked = selected;
        }

        #endregion

        #region Touch Invokes

        public override void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e))
                {
                    if (_enabled)
                    {
                        _checked = !_checked;
                        Render(true);
                    }
                    OnTap(this, new point(e.X - Left, e.Y - Top));
                }
                _mDown = false;
            }
        }

        #endregion

        #region  Properties

        public bool Value
        {
            get { return _checked; }
            set
            {
                _checked = value;
                Render(true);
            }
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend || !_parent.ScreenBounds.intersects(this.ScreenBounds)) return;

            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);
            _parent.ScreenBuffer.DrawRectangle((_enabled) ? Color.Black : Colors.DarkGray, 1, Left, Top, 16, 16, 0, 0, (_enabled) ? Colors.White : Colors.Gray, Left, Top, (_enabled) ? Colors.DarkGray : Colors.Gray, Left, Top + 14, 256);

            if (_checked)
            {
                Color chk = (_enabled) ? Colors.Black : Colors.LightGray;
                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 3, Top + 3, Left + _w - 6, Top + _h - 6);
                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 3, Top + _h - 6, Left + _w - 6, Top + 3);

                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 4, Top + 3, Left + _w - 6, Top + _h - 7);
                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 3, Top + _h - 7, Left + _w - 7, Top + 3);

                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 3, Top + 4, Left + _w - 7, Top + _h - 6);
                _parent.ScreenBuffer.DrawLine(chk, 1, Left + 4, Top + _h - 6, Left + _w - 6, Top + 4);
            }

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

    }
}
