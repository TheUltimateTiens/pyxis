/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class TabDialog : Control
    {

        #region Variables

        private int _selIndex = 0;
        private int _TabWidth = 0;
        private int _selDown = 0;

        private ArrayList _Tabs = new ArrayList();

        #endregion

        #region Constructors

        public TabDialog(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public TabDialog(int x, int y, int width, int height, Tab[] Tabs)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            for (int i = 0; i < Tabs.Length; i++)
            {
                Tabs[i].Width = _w - 2;
                Tabs[i].Height = _h - 26;
                Tabs[i].Parent = this;
                Tabs[i].Visible = (i == 0) ? true : false;
                Tabs[i].SetOffset(this, new point(Left + 1, Top + 25));
                _Tabs.Add(Tabs[i]);
            }
            CalculateTabWidth();
        }

        #endregion

        #region Touch Invokes

        public override void TouchDown(object sender, point e)
        {
            if (!_visible) return;

            // Check Tab CommandButtons
            Tab tb;
            for (int i = 0; i < _Tabs.Count; i++)
            {
                tb = (Tab)_Tabs[i];
                if (tb.Bounds.contains(e))
                {
                    _selDown = i;
                    return;
                }
            }

            // Check Active Tab
            try
            {
                tb = (Tab)_Tabs[_selIndex];
                tb.TouchDown(this, e);
            }
            catch (Exception) { }
        }

        public override void TouchUp(object sender, point e)
        {
            if (!_visible) return;

            // Check Tab CommandButtons
            Tab tb;
            for (int i = 0; i < _Tabs.Count; i++)
            {
                tb = (Tab)_Tabs[i];
                if (tb.Bounds.contains(e) && _selDown == i)
                {
                    _selIndex = i;
                    _selDown = 0;
                    _parent.Render();
                    Render(true);
                    return;
                }
            }

            // Check Active Tab
            try
            {
                tb = (Tab)_Tabs[_selIndex];
                tb.TouchUp(this, e);
            }
            catch (Exception) { }
        }

        public override void TouchMove(object sender, point e)
        {
            // Check Active Tab
            try
            {
                Tab tb = (Tab)_Tabs[_selIndex];
                tb.TouchUp(this, e);
            }
            catch (Exception) { }
        }

        #endregion

        #region Public Methods

        public void AddTab(Tab NewTab)
        {
            NewTab.Width = _w - 2;
            NewTab.Height = _h - 26;
            NewTab.Visible = false;
            NewTab.Parent = this;
            NewTab.SetOffset(this, new point(Left + 1, Top + 25));
            _Tabs.Add(NewTab);
            CalculateTabWidth();
            Render(true);
        }

        public void RemoveTab(Tab Tab)
        {
            _Tabs.Remove(Tab);
            CalculateTabWidth();
            Render(true);
        }

        public void RemoveTabAt(int Index)
        {
            _Tabs.RemoveAt(Index);
            CalculateTabWidth();
            Render(true);
        }

        #endregion

        #region Internal Methods

        public override void SetOffset(Control sender, point e)
        {
            if (sender != _parent)
                throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.X;
            _yOffset = e.Y;

            Control ctrl;
            for (int i = 0; i < _Tabs.Count; i++)
            {
                ctrl = (Tab)_Tabs[i];
                ctrl.SetOffset(this, new point(Left + 1, Top + 25));
            }
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            // Draw Outline
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, Left, Top + 23, _w, _h - 23, 0, 0, 0, 0, 0, 0, 0, 0, 0);

            // Draw Tabs
            Tab tb;
            int x = Left;
            int y = Top;
            for (int i = 0; i < _Tabs.Count; i++)
            {
                tb = (Tab)_Tabs[i];

                if (tb.Enabled)
                {
                    tb.Bounds = new rect(x, y, _TabWidth, 24);

                    if (i == _selIndex)
                    {
                        _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, x, y, _TabWidth, 24, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
                        _parent.ScreenBuffer.DrawLine(Colors.LightGray, 1, x + 1, y + 23, x + _TabWidth - 2, y + 23);
                        _parent.ScreenBuffer.DrawTextInRect(tb.Title, x + 2, y + 4, _TabWidth - 4, 20, Bitmap.DT_AlignmentCenter, Colors.Black, FontManager.Arial);
                        tb.Visible = true;
                        tb.Render();

                        // Reset clipping region in case we're off parent somewhere (can happen w/ scroll)
                        _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);
                    }
                    else
                    {
                        _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, x, y + 2, _TabWidth, 22, 0, 0, Colors.Wheat, 0, 0, Colors.Wheat, 0, 0, 256);
                        _parent.ScreenBuffer.DrawTextInRect(tb.Title, x + 2, y + 6, _TabWidth - 4, 18, Bitmap.DT_AlignmentCenter, Colors.Gray, FontManager.Arial);
                        tb.Visible = false;
                    }

                    x += _TabWidth - 1;
                }
            }

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

        #region Private Methods

        private void CalculateTabWidth()
        {
            Tab tb;
            int mW = 0;
            int tW;
            int tC = 0;

            // Get the longest string width
            for (int i = 0; i < _Tabs.Count; i++)
            {
                tb = (Tab)_Tabs[i];
                if (tb.Enabled)
                {
                    tW = FontManager.ComputeExtentEx(FontManager.Arial, tb.Title).Width;
                    if (tW > mW) mW = tW;
                    tC++;
                }
            }

            // Determine size
            long TS = ((mW + 10) * tC);
            if (TS < _w)
            {
                _TabWidth = mW + 10; 
            }
            else
            {
                _TabWidth = _w / tC;
            }
        }

        #endregion

    }
}
