using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation.Media;

using Skewworks.Pyxis.EXT;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class IconShortcut : Control
    {

        #region Variables

        private Image32 _icon;
        private string _title;

        #endregion

        #region Constructors

        public IconShortcut(Image32 Image, string Title, int X, int Y, int Width, int Height)
        {
            _icon = Image;
            _title = Title;
            _x = X;
            _y = Y;
            _w = Width;
            _h = Height;
        }

        #endregion

        #region Properties

        public Image32 Icon
        {
            get { return _icon; }
            set 
            {
                if (value.Width > 32 || value.Height > 32)
                    throw new Exception("Image too large");

                _icon = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            int w, h;
            int offset = 0;

            if (_icon != null)
                _icon.draw(_parent.ScreenBuffer, Left + ((_w / 2) - (_icon.Width / 2)), Top);

            FontManager.Arial.ComputeTextInRect(_title, out w, out h, _w - 4);
            w += 4;
            h += 4;

            if (h > _h - 35) h = _h - 35;

            offset = (_w / 2) - (w / 2);

            _parent.ScreenBuffer.DrawRectangle(Color.Black, 0, Left + offset, Top + 36, w, h, 0, 0, Color.Black, 0, 0, Color.Black, 0, 0, 150);
            _parent.ScreenBuffer.DrawTextInRect(_title, Left + 2 + offset, Top + 38, w - 4, h - 4, Bitmap.DT_WordWrap + Bitmap.DT_AlignmentCenter, Color.White, FontManager.Arial);
        }

        #endregion

    }
}
