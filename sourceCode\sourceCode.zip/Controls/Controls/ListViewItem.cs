/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation.Media;

using Skewworks.Pyxis.EXT;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class ListViewItem : MarshalByRefObject
    {

        #region Variables

        private string _text = string.Empty;        // Text to display (first column)
        private Color _bkg = Color.White;           // Color for background (if enabled)
        private Color _fore = Color.Black;          // Color to render text in (if enabled)
        private bool _enabled = true;               // True if enabled
        private bool _visible = true;               // True if visible
        private bool _checked;                      // True if checked
        private Font _fnt = FontManager.Arial;      // Font for the item
        private ArrayList _subitems;                // ArrayList of sub items (additional colums)
        private Control _parent;
        private rect _bounds;
        private object _tag;

        #endregion

        #region Constructor

        public ListViewItem()
        {
            _subitems = new ArrayList();
        }

        public ListViewItem(string Text)
        {
            _subitems = new ArrayList();
            _text = Text;
        }

        public ListViewItem(string[] Values)
        {
            _subitems = new ArrayList();
            _text = Values[0];
            for (int i = 1; i < Values.Length; i++)
                _subitems.Add(Values[i]);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/Sets the background color
        /// </summary>
        public Color Background
        {
            get { return _bkg; }
            set
            {
                _bkg = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public bool Checked
        {
            get { return _checked; }
            set
            {
                _checked = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public bool Enabled
        {
            get { return _enabled; }
            set
            {
                _enabled = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public Font Font
        {
            get { return _fnt; }
            set
            {
                _fnt = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public int Length
        {
            get { return _subitems.Count; }
        }

        public Control Parent
        {
            get { return _parent; }
            set
            {
                if (value is ListView)
                    _parent = value;
                else
                    throw new Exception("ListViewItems can only be added to ListView objects");
            }
        }

        public object Tag
        {
            get { return _tag; }
            set { _tag = value; }
        }

        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        public bool Visible
        {
            get { return _visible; }
            set
            {
                _visible = value;
                if (_parent != null)
                    _parent.Render(true);
            }
        }

        #endregion

        #region Public Methods

        public void AddSubItem(string Text)
        {
            _subitems.Add(Text);
        }

        public void ClearSubItems()
        {
            _subitems.Clear();
        }

        public string GetSubItem(int Index)
        {
            return (string)_subitems[Index];
        }

        public void RemoveSubItemAt(int Index)
        {
            _subitems.RemoveAt(Index);
        }

        public void SetSubItem(int Index, string Value)
        {
            _subitems[Index] = Value;
        }

        #endregion

    }
}
