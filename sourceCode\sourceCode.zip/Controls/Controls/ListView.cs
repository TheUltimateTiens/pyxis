using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class ListView : Control
    {
    }
}
