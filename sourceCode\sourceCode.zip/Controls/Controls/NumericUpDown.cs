/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;
using System.Threading;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class NumericUpDown : Control
    {

        #region Variables

        private int _min = 0;
        private int _max = 100;
        private int _val = 0;
        private bool _force = false;
        private int _chgVal;
        private Thread _changer;

        #endregion

        #region Constructors

        public NumericUpDown(int x, int y, int width, int Minimum, int Maximum)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = 20;
            _max = Maximum;
            _min = Minimum;
        }

        public NumericUpDown(int x, int y, int width, int Minimum, int Maximum, int value)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = 20;
            _max = Maximum;
            _min = Minimum;
            _val = value;
        }

        #endregion

        #region Events

        public event OnValueChanged ValueChanged;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnValueChanged(Object sender, int value)
        {
            if (ValueChanged != null) ValueChanged(sender, value);
        }

        #endregion

        #region Touch Invokes

        public override void TouchDown(object sender, point e)
        {
            if (!_enabled || !_visible) return;
            
            _mDown = true;

            // Check Up
            if (new rect(Left + _w - 16, Top, 16, 10).contains(e))
            {
                Value = _val + 1;
                _chgVal = 1;
                _changer = new Thread(AutoIncDec);
                _changer.Priority = ThreadPriority.AboveNormal;
                _changer.Start();
                return;
            }

            // Check Down
            if (new rect(Left + _w - 16, Top + 10, 16, 10).contains(e))
            {
                Value = _val - 1;
                _chgVal = -1;
                _changer = new Thread(AutoIncDec);
                _changer.Priority = ThreadPriority.AboveNormal;
                _changer.Start();
                return;
            }

        }

        public override void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.X - Left, e.Y - Top));
                _mDown = false;
            }
        }

        #endregion

        #region  Properties

        public bool ForceZeros
        {
            get { return _force; }
            set { _force = value; }
        }

        public int Minimum
        {
            get { return _min; }
            set
            {
                if (value >= _max) value = _max - 1;
                _min = value;
                Render(true);
            }
        }

        public int Maximum
        {
            get { return _max; }
            set
            {
                if (value <= _min) value = _min + 1;
                _max = value;
                Render(true);
            }
        }

        public int Value
        {
            get { return _val; }
            set
            {
                if (value < _min) value = _min;
                if (value > _max) value = _max;
                _val = value;
                Render(true);
                OnValueChanged(this, _val);
            }
        }

        public override int Height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                _parent.Render();
            }
        }
        
        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, Left, Top, _w + 1, 21, 0, 0, (_enabled) ? Colors.White : Colors.LightGray, 0, 0, (_enabled) ? Colors.White : Colors.LightGray, 0, 0, 256);
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, Left + _w - 16, Top, 17, 21, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            _parent.ScreenBuffer.DrawLine(Colors.Black, 1, Left + _w - 15, Top + 10, Left + _w, Top + 10);
            _parent.ScreenBuffer.DrawImage(Left + _w - 12, Top + 3, Resources.GetBitmap(Resources.BitmapResources.up), 0, 0, 9, 5);
            _parent.ScreenBuffer.DrawImage(Left + _w - 12, Top + 13, Resources.GetBitmap(Resources.BitmapResources.down), 0, 0, 9, 5);

            _parent.ScreenBuffer.DrawTextInRect((_force) ? IntToNString(Value, Maximum.ToString().Length) : Value.ToString(), Left + 1, Top + 2, _w - 18, 16, Bitmap.DT_AlignmentRight, (_enabled) ? Colors.Black : Colors.Gray, FontManager.Arial);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

        #region Private Methods

        private void AutoIncDec()
        {
            int iWait = 750;
            while (_mDown)
            {
                Thread.Sleep(iWait);
                if (!_mDown) return;
                Value = _val + _chgVal;
                switch (iWait)
                {
                    case 750:
                        iWait = 500;
                        break;
                    case 500:
                        iWait = 250;
                        break;
                    case 250:
                        iWait = 75;
                        break;
                }
            }
        }

        private string IntToNString(int value, int len)
        {
            string val = value.ToString();
            if (val.Length >= len) return val;

            while (val.Length < len)
                val = "0" + val;

            return val;
        }

        #endregion

    }
}
