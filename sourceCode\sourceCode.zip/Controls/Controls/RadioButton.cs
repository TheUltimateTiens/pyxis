/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class RadioCommandButton : Control
    {

        #region Variables

        private string _group = "defaultGroup";
        protected internal bool _checked = false;

        #endregion

        #region Constructors

        public RadioCommandButton(int x, int y)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
        }

        public RadioCommandButton(int x, int y, string group)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
            _group = group;
        }

        public RadioCommandButton(int x, int y, bool selected)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
            _checked = selected;
        }

        public RadioCommandButton(int x, int y, string group, bool selected)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
            _group = group;
            _checked = selected;
        }

        #endregion

        #region  Properties

        public string Group
        {
            get { return _group; }
            set { _group = value; }
        }

        public bool Value
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                if (value == true && _parent != null)
                {
                    Container prt = (Container)_parent;
                    for (int i = 0; i < prt.Children.Count; i++)
                    {
                        Control ctrl = (Control)prt.Children[i];
                        if (ctrl is RadioCommandButton)
                        {
                            RadioCommandButton rb = (RadioCommandButton)ctrl;
                            rb.Value = false;
                        }
                    }
                }
                Render(true);
            }
        }

        public override int Height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }
        
        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            _parent.ScreenBuffer.DrawEllipse((_enabled) ? Colors.Gray : Colors.DarkGray, 1, Left + 9, _y + 9, 9, 9, (_enabled) ? Colors.White : Colors.Gray, 0, 0, (_enabled) ? Colors.White : Colors.Gray, 0, 0, 255);
            _parent.ScreenBuffer.DrawEllipse((_checked) ? ColorUtility.ColorFromRGB(117, 184, 2) : ColorUtility.ColorFromRGB(156, 156, 156), 1, Left + 9, _y + 9, 5, 5, (_checked) ? ColorUtility.ColorFromRGB(190, 253, 80) : ColorUtility.ColorFromRGB(210, 210, 210), 0, 0, (_enabled) ? Color.White : Colors.Gray, 0, 0, 255);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

    }
}
