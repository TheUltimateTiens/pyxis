/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class TreeviewNode : MarshalByRefObject
    {

        #region Variables

        private rect _Bounds;
        private bool _sel = false;
        private object _tag;
        private string _text;
        private TreeviewNode _parent;
        private Treeview _container;
        private ArrayList _nodes = new ArrayList();
        private bool _expanded = false;
        private bool _mDown = false;

        #endregion

        #region Constructors

        public TreeviewNode(string Text)
        {
            _text = Text;
        }

        public TreeviewNode(string Text, object Tag)
        {
            _text = Text;
            _tag = Tag;
        }

        #endregion

        #region Properties

        internal rect Bounds
        {
            get { return _Bounds; }
            set { _Bounds = value; }
        }

        public Treeview Container
        {
            get { return _container; }
            internal set { _container = value; }
        }

        public bool Expanded
        {
            get { return _expanded; }
            set
            {
                if (_nodes.Count == 0) value = false;
                if (_expanded == value) return;
                _expanded = value;
                if (_container != null) _container.Render(true);
            }
        }

        public int Length
        {
            get { return _nodes.Count; }
        }

        public TreeviewNode Parent
        {
            get { return _parent; }
            internal set { _parent = value; }
        }

        internal bool PenDown
        {
            get { return _mDown; }
            set { _mDown = value; }
        }

        public bool Selected
        {
            get { return _sel; }
            internal set { _sel = value; }
        }

        public object Tag
        {
            get { return _tag; }
            set { _tag = value; }
        }

        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                if (_container != null) _container.Render(true);
            }
        }

        #endregion

        #region Public Methods

        public void AddNode(TreeviewNode node)
        {
            node.Parent = this;
            node.Container = _container;
            _nodes.Add(node);
            if (_expanded || _nodes.Count == 1 && _container != null) _container.Render(true);
        }

        public void ClearNodes()
        {
            _nodes.Clear();
            Expanded = false;
        }

        public TreeviewNode Node(int index)
        {
            return (TreeviewNode)_nodes[index];
        }

        public void RemoveNode(TreeviewNode node)
        {
            _nodes.Remove(node);
            Expanded = _expanded;   // Automatically updates for 0 nodes
        }

        public void RemoveNodeAt(int index)
        {
            _nodes.RemoveAt(index);
            Expanded = _expanded;   // Automatically updates for 0 nodes
        }

        #endregion

    }
}
