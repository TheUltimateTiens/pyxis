﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General InFormation about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the inFormation
// associated with an assembly.
[assembly: AssemblyTitle("Kernel")]
[assembly: AssemblyDescription("Kernal for Pyxis 2")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skewworks")]
[assembly: AssemblyProduct("Pyxis")]
[assembly: AssemblyCopyright("Copyright © 2010 Thomas W. Holtquist")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version inFormation for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.0.0.9")]
[assembly: AssemblyFileVersion("2.0.0.9")]
