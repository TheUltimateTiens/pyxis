/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class button : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private string _text = "";
        private Font _font = Resources.GetFont(Resources.FontResources.tahoma11);
        private Color _color = Color.Black;
        private PressedState _pressed = PressedState.Normal;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public button(string text, int x, int y)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = 75;
            _h = 25;
        }

        public button(string text, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public button(string text, Font font, Color ForeColor, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _font = font;
            _color = ForeColor;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mDown = true;
            if (_enabled)
            {
                _pressed = PressedState.Pressed;
                Render(true);
            }
        }

        public void TouchUp(object sender, point e)
        {
            if (_pressed == PressedState.Pressed && _enabled)
            {
                _pressed = PressedState.Normal;
                Render(true);
                if (_mDown)
                {
                    if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.x - left, e.y - top));
                    _mDown = false;
                }
            }
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public string text
        {
            get { return _text; }
            set { _text = value; Render(true); }
        }

        public Font font
        {
            get { return _font; }
            set { _font = value; Render(true); }
        }

        public Color color
        {
            get { return _color; }
            set { _color = value; Render(true); }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Public Methods

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            Color back1 = ColorUtility.ColorFromRGB(242, 242, 242);
            Color back2 = ColorUtility.ColorFromRGB(207, 207, 207);

            //// Draw Border & Background
            _parent.ScreenBuffer.DrawRectangle(ColorUtility.ColorFromRGB(112, 112, 112), 1, left, top, _w, _h, 1, 1, Color.Black, 0, 0, Color.Black, 0, 0, 0);
            _parent.ScreenBuffer.DrawRectangle(Color.White, 1, left + 1, top + 1, _w - 2, _h - 2, 0, 0, (_pressed == PressedState.Normal) ? back1 : back2, 0, 0, (_pressed == PressedState.Normal) ? back1 : back2, 0, 0, 256);
            _parent.ScreenBuffer.DrawRectangle(Color.White, 0, left + 2, top + (_h / 2), _w - 4, (_h / 2) - 1, 0, 0, (_pressed == PressedState.Normal) ? back2 : back1, 0, 0, (_pressed == PressedState.Normal) ? back2 : back1, 0, 0, 256);


            _parent.ScreenBuffer.DrawTextInRect(_text, left + 3, top + 4, _w - 6, _h - 8, Bitmap.DT_AlignmentCenter + Bitmap.DT_TrimmingNone, (_enabled) ? _color : Colors.DarkGray, _font);

            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

    }
}
