/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class listbox : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private Color _bkg = Colors.LightGray;
        private ArrayList _items = new ArrayList();
        private int _selIndex = -1;
        private int _scrollY = 0;
        private int _mY = 0;
        private bool _bMoved = false;

        #endregion

        #region Contructors

        public listbox(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public listbox(int x, int y, int width, int height, string[] items)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            for (int i = 0; i < items.Length; i++)
            {
                _items.Add(items[i]);
            }
            if (items != null) _selIndex = 0;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mY = e.y;
            _mDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (_bMoved)
                {
                    _bMoved = false;
                }
                else
                {
                    if (this.ScreenBounds.contains(e))
                    {
                        int y = e.y - top + -(_scrollY);
                        int index = 0;
                        while (y > 32)
                        {
                            y -= 32;
                            index++;
                        }
                        if (index <= _items.Count)
                        {
                            SelectedIndex = index;
                        }

                        OnTap(this, new point(e.x - left, e.y - top));
                    }
                }
                _mDown = false;
            }
        }

        public void TouchMove(object sender, point e)
        {
            int nScroll = _scrollY + (e.y - _mY);
            if (nScroll > 0) nScroll = 0;
            if (nScroll < -(_items.Count * 32) + _h - 2) nScroll = -(_items.Count * 32) + _h - 2;
            _mY = e.y;
            _bMoved = true;
            if (_scrollY != nScroll)
            {
                _scrollY = nScroll;
                Render(true);
            }
        }

        #endregion

        #region  Properties

        public int SelectedIndex
        {
            get { return _selIndex; }
            set
            {
                if (_selIndex == value) return;
                _selIndex = value;
                Render(true);
                OnSelectedIndexChange(this, value);
            }
        }

        public string SelectedItem
        {
            get { return (string)_items[_selIndex]; }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null)  _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; if (_parent != null) _parent.Render(); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend) Render(true);
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public Color backcolor
        {
            get { return _bkg; }
            set
            {
                _bkg = value;
                Render(true);
            }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        public event OnSelectedIndexChange SelectedIndexChanged;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnSelectedIndexChange(Object sender, int e)
        {
            if (SelectedIndexChanged != null) SelectedIndexChanged(sender, e);
        }

        #endregion

        #region Public Methods

        public void AddItem(string text)
        {
            _items.Add(text);
            if (_selIndex < 0) _selIndex = 0;
            Render(true);
        }

        public void RemoveItem(string text)
        {
            _items.Remove(text);
            if (_selIndex > _items.Count) _selIndex = _items.Count;
            Render(true);
        }

        public void RemoveItemAt(int index)
        {
            _items.RemoveAt(index);
            if (_selIndex > _items.Count) _selIndex = _items.Count;
            Render(true);
        }

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (!_visible || _parent == null || _parent.ScreenBuffer == null || _suspend) return;

            _parent.ScreenBuffer.DrawRectangle(Color.Black, 1, left, top, _w, height, 1, 1, _bkg, 0, 0, _bkg, 0, 0, 256);

            int totalH = _items.Count * 32;
            int wOffset = 0;
            int y = _scrollY + top + 1;
            bool bScroll = false;

            _parent.ScreenBuffer.SetClippingRectangle(left + 1, top + 1, _w - 2, _h - 2);

            if (totalH > _h)
            {
                wOffset = 8;
                bScroll = true;
            }

            for (int i = 0; i < _items.Count; i++)
            {
                _parent.ScreenBuffer.DrawRectangle(Color.White, 1, left + 1, y, _w - 2, 32, 0, 0, Color.White, 0, 0, Color.White, 0, 0, 256);

                if (i < _items.Count - 1) _parent.ScreenBuffer.DrawLine(Colors.LightGray, 1, x + 5, y + 31, x + _w - 10 - wOffset, y + 31);

                _parent.ScreenBuffer.DrawEllipse((_enabled) ? Colors.Gray : Colors.DarkGray, 1, left + 16, y + 15, 9, 9, (_enabled) ? Colors.White : Colors.Gray, 0, 0, (_enabled) ? Colors.White : Colors.Gray, 0, 0, 255);
                _parent.ScreenBuffer.DrawEllipse((i == _selIndex) ? ColorUtility.ColorFromRGB(117, 184, 2) : ColorUtility.ColorFromRGB(156, 156, 156), 1, left + 16, y + 15, 5, 5, (i == _selIndex) ? ColorUtility.ColorFromRGB(190, 253, 80) : ColorUtility.ColorFromRGB(210, 210, 210), 0, 0, (_enabled) ? Color.White : Colors.Gray, 0, 0, 255);

                _parent.ScreenBuffer.DrawTextInRect((string)_items[i], x + 42, y + 9, _w - 33 - wOffset, 20, Bitmap.DT_AlignmentLeft + Bitmap.DT_TrimmingCharacterEllipsis, Color.Black, Resources.GetFont(Resources.FontResources.tahoma11));

                y += 32;
            }

            if (bScroll)
            {
                _parent.ScreenBuffer.DrawRectangle(Colors.DarkGray, 1, left + _w - 9, top + 1, 9, _h - 2, 0, 0, Colors.DarkGray, 0, 0, Colors.DarkGray, 0, 0, 256);

                float sH = (float)(totalH - _h);
                float sY = (sH == 0) ? 0 : -((float)_scrollY) / (float)(totalH - _h);
                int iSY = (int)((float)(_h - 24) * sY);
                _parent.ScreenBuffer.DrawRectangle(Colors.LightGray, 1, left + _w - 9, top + 1 + iSY, 9, 20, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            }


            _parent.ScreenBuffer.SetClippingRectangle(0, 0, _parent.ScreenBuffer.Width, _parent.ScreenBuffer.Height);
            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

    }
}
