/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    public class treeview : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private ArrayList _nodes = new ArrayList();

        private int _scrollY = 0;
        private int _mY = 0;
        private int _scrollX = 0;
        private int _mX = 0;
        private bool _bMoved = false;

        private int _aH = 0;
        private int _aW = 0;
        private int _totalH = 0;
        private int _totalW = 0;

        private treeviewnode _selNode = null;

        #endregion

        #region Events

        public event OnNodeTap NodeTapped;
        public event OnNodeCollapsed NodeCollapsed;
        public event OnNodeExpanded NodeExpanded;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnNodeCollapsed(object sender, treeviewnode node)
        {
            if (NodeCollapsed != null) NodeCollapsed(sender, node);
        }

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnNodeExpanded(object sender, treeviewnode node)
        {
            if (NodeExpanded != null) NodeExpanded(sender, node);
        }

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnNodeTap(treeviewnode node, point e)
        {
            if (NodeTapped != null) NodeTapped(node, e);
        }

        #endregion

        #region Constructors

        public treeview(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mY = e.y;
            _mX = e.x;
            treeviewnode node = NodeFromPoint(e);
            if (node != null) node.PenDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (_bMoved)
            {
                _bMoved = false;
            }
            else
            {
                // Get Selected Node
                treeviewnode node = NodeFromPoint(e);
                rect ecRect;
                if (node != null)
                {
                    ecRect = new rect(node.Bounds.x, node.Bounds.y, 13, 20);
                    if (ecRect.contains(e) && node.PenDown)
                    {
                        node.Expanded = !node.Expanded;
                        if (node.Expanded)
                        {
                            OnNodeExpanded(this, node);
                        }
                        else
                        {
                            ResetChildrenBounds(node);
                            OnNodeCollapsed(this, node);
                        }

                        Render(true);
                    }
                    else
                    {
                        // Reset States
                        if (!node.Selected && node.PenDown)
                        {
                            for (int i = 0; i < _nodes.Count; i++) ResetNodesState((treeviewnode)_nodes[i]);
                            node.Selected = true;
                            _selNode = node;
                            Render(true);
                        }
                        OnNodeTap(node, e);
                    }
                }

                // Reset Pen States
                for (int i = 0; i < _nodes.Count; i++) SetChildrenPen((treeviewnode)_nodes[i]);
            }
        }

        public void TouchMove(object sender, point e)
        {
            bool bRender = false;

            if (_totalH > _h)
            {
                int nScroll = _scrollY + (e.y - _mY);
                if (nScroll > 0) nScroll = 0;
                if (nScroll < -_totalH + _aH - 2) nScroll = -_totalH + _aH - 2;
                _mY = e.y;
                _bMoved = true;
                if (_scrollY != nScroll)
                {
                    _scrollY = nScroll;
                    bRender = true;
                }
            }

            if (_totalW > _w)
            {
                int nScroll = _scrollX + (e.x - _mX);
                if (nScroll > 0) nScroll = 0;
                if (nScroll < -_totalW + _aW - 2) nScroll = -_totalW + _aW - 2;
                _mX = e.x;
                _bMoved = true;
                if (_scrollX != nScroll)
                {
                    _scrollX = nScroll;
                    bRender = true;
                }
            }

            if (bRender) Render(true);
        }

        #endregion

        #region  Properties

        public treeviewnode SelectedNode
        {
            get { return _selNode; }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Public Methods

        public void AddNode(treeviewnode node)
        {
            node.Container = this;
            _nodes.Add(node);
            Render(true);
        }

        public void ClearNodes()
        {
            _nodes.Clear();
            Render(true);
        }

        public treeviewnode Node(int index)
        {
            return (treeviewnode)_nodes[index];
        }

        public void RemoveNode(treeviewnode node)
        {
            _nodes.Remove(node);
            Render(true);
        }

        public void RemoveNodeAt(int index)
        {
            _nodes.RemoveAt(index);
            Render(true);
        }

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        internal void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            int y = 4;
            int x = 4;
            int insert = 13;
            Bitmap exp = Resources.GetBitmap(Resources.BitmapResources.expand);
            Bitmap col = Resources.GetBitmap(Resources.BitmapResources.collapse);
            Font fnt = FontManager.Tahoma11;
            treeviewnode node;
            point e;
            int maxX = _w;
            int tW, tH;
            bool bResetScroll = false;

            // Draw the border & background
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, left, top, _w, _h, 0, 0, Colors.White, 0, 0, Colors.White, 0, 0, 256);

            // Draw the Items
            _parent.ScreenBuffer.SetClippingRectangle(left + 1, top + 1, _w - 2, _h - 2);
            for (int i = 0; i < _nodes.Count; i++)
            {
                node = (treeviewnode)_nodes[i];

                // Set bounds so we can check hits
                fnt.ComputeExtent(node.Text, out tW, out tH);
                node.Bounds = new rect(_scrollX + left + x, _scrollY + top + y, tW + 13, 20);
                if (maxX < tW + 13 + x) maxX = tW + 13 + x;

                // Draw Icon only if there are children
                if (node.Length > 0)
                {
                    _parent.ScreenBuffer.DrawImage(_scrollX + left + x, _scrollY + top + y + 2, (node.Expanded) ? col : exp, 0, 0, 9, 9);
                }

                // Draw the text
                _parent.ScreenBuffer.DrawText(node.Text, fnt, (node.Selected) ? Colors.Blue : Colors.Black, _scrollX + left + x + 13, _scrollY + top + y);
                y += 20;

                if (node.Expanded)
                {
                    e = RenderSubNodes(node, x + insert, y, insert);
                    y = e.y;
                    if (e.x > maxX) maxX = e.x;
                }

            }
            _parent.ScreenBuffer.SetClippingRectangle(0, 0, _parent.ScreenBuffer.Width, _parent.ScreenBuffer.Height);

            // Scrolling
            _aH = _h;
            _aW = _w;
            _totalH = y;
            _totalW = maxX;
            if (maxX > _w)
            {
                _totalH += 10;
                _aH -= 10;
            }
            if (y > _h)
            {
                _totalW += 10;
                _aW -= 10;
            }

            if (y > _h)
            {
                _parent.ScreenBuffer.DrawRectangle(Colors.DarkGray, 1, left + _w - 10, top + 1, 9, _aH - 2, 0, 0, Colors.DarkGray, 0, 0, Colors.DarkGray, 0, 0, 256);

                float sH = (float)(_totalH - _aH);
                float sY = (sH == 0) ? 0 : -((float)_scrollY) / (float)(_totalH - _aH);
                int iSY = (int)((float)(_aH - 24) * sY);
                _parent.ScreenBuffer.DrawRectangle(Colors.LightGray, 1, left + _w - 10, top + 1 + iSY, 9, 20, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            }
            else if (_scrollY < 0)
            {
                _scrollY = 0;
                bResetScroll = true;
            }

            if (maxX > _w)
            {
                _parent.ScreenBuffer.DrawRectangle(Colors.DarkGray, 1, left + 1, top + _h - 10, _aW - 2, 9, 0, 0, Colors.DarkGray, 0, 0, Colors.DarkGray, 0, 0, 256);

                float sW = (float)(_totalW - _aW);
                float sX = (sW == 0) ? 0 : -((float)_scrollX) / (float)(_totalW - _aW);
                int iSX = (int)((float)(_aW - 24) * sX);
                _parent.ScreenBuffer.DrawRectangle(Colors.LightGray, 1, left + 1 + iSX, top + _h - 10, 20, 9, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            }
            else if (_scrollX < 0)
            {
                _scrollX = 0;
                bResetScroll = true;
            }

            if (bResetScroll)
            {
                Render(flush);
                return;
            }

            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        private point RenderSubNodes(treeviewnode node, int x, int y, int insert)
        {
            Bitmap exp = Resources.GetBitmap(Resources.BitmapResources.expand);
            Bitmap col = Resources.GetBitmap(Resources.BitmapResources.collapse);
            Font fnt = FontManager.Tahoma11;
            treeviewnode subnode;
            point e;
            int maxX = x;
            int tW, tH;

            // Draw the Items
            for (int i = 0; i < node.Length; i++)
            {
                subnode = node.Node(i);

                // Set bounds so we can check hits
                fnt.ComputeExtent(subnode.Text, out tW, out tH);
                subnode.Bounds = new rect(_scrollX + left + x, _scrollY + top + y, tW + 13, 20);
                if (maxX < tW + 13 + x) maxX = tW + 13 + x;

                // Draw Icon only if there are children
                if (subnode.Length > 0)
                {
                    _parent.ScreenBuffer.DrawImage(_scrollX + left + x, _scrollY + top + y + 2, (subnode.Expanded) ? col : exp, 0, 0, 9, 9);
                }

                // Draw the text
                _parent.ScreenBuffer.DrawText(subnode.Text, fnt, (subnode.Selected) ? Colors.Blue : Colors.Black, _scrollX + left + x + 13, _scrollY + top + y);
                y += 20;

                if (subnode.Expanded)
                {
                    e = RenderSubNodes(subnode, x + insert, y, insert);
                    y = e.y;
                    if (e.x > maxX) maxX = e.x;
                }

            }

            return new point(maxX, y);
        }

        #endregion

        #region Private Methods

        private treeviewnode NodeFromPoint(point e)
        {
            treeviewnode node;
            for (int i = 0; i < _nodes.Count; i++)
            {
                node = (treeviewnode)_nodes[i];
                if (node.Bounds.contains(e)) return node;
                if (node.Length > 0)
                {
                    node = CheckNodePoint(node, e);
                    if (node != null) return node;
                }
            }
            return null;
        }

        private treeviewnode CheckNodePoint(treeviewnode node, point e)
        {
            treeviewnode subnode;
            for (int i = 0; i < node.Length; i++)
            {
                subnode = node.Node(i);
                if (subnode.Bounds.contains(e)) return subnode;
                if (subnode.Length > 0)
                {
                    subnode = CheckNodePoint(subnode, e);
                    if (subnode != null) return subnode;
                }
            }
            return null;
        }

        private void SetChildrenPen(treeviewnode node)
        {
            node.PenDown = false;
            treeviewnode subnode;
            for (int i = 0; i < node.Length; i++)
            {
                subnode = node.Node(i);
                subnode.PenDown = false;
                if (subnode.Length > 0) SetChildrenPen(subnode);
            }
        }

        private void SetChildrenSelected(treeviewnode node)
        {
            _selNode = null;
            node.Selected = false;
            treeviewnode subnode;
            for (int i = 0; i < node.Length; i++)
            {
                subnode = node.Node(i);
                subnode.Selected = false;
                if (subnode.Length > 0) SetChildrenSelected(subnode);
            }
        }

        private void ResetNodesState(treeviewnode topNode)
        {
            _selNode = null;
            topNode.Selected = false;
            topNode.PenDown = false;

            treeviewnode subnode;
            for (int i = 0; i < topNode.Length; i++)
            {
                subnode = topNode.Node(i);
                subnode.Selected = false;
                subnode.PenDown = false;
                if (subnode.Length > 0) SetChildrenSelected(subnode);
            }
        }

        private void ResetChildrenBounds(treeviewnode node)
        {
            treeviewnode subnode;
            for (int i = 0; i < node.Length; i++)
            {
                subnode = node.Node(i);
                subnode.Bounds = new rect(0, 0, 0, 0);
                if (subnode.Length > 0) ResetChildrenBounds(subnode);
            }
        }

        #endregion

    }
}
