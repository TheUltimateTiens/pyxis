/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class tabdialog : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;
        private int _selIndex = 0;
        private int _tabWidth = 0;
        private int _selDown = 0;

        private ArrayList _tabs = new ArrayList();

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public tabdialog(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public tabdialog(int x, int y, int width, int height, tab[] tabs)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            for (int i = 0; i < tabs.Length; i++)
            {
                tabs[i].width = _w - 2;
                tabs[i].height = _h - 26;
                tabs[i].parent = this;
                tabs[i].visible = (i == 0) ? true : false;
                tabs[i].SetOffset(this, new point(left + 1, top + 25));
                _tabs.Add(tabs[i]);
            }
            CalculateTabWidth();
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            if (!visible) return;

            // Check tab buttons
            tab tb;
            for (int i = 0; i < _tabs.Count; i++)
            {
                tb = (tab)_tabs[i];
                if (tb.bounds.contains(e))
                {
                    _selDown = i;
                    return;
                }
            }

            // Check Active Tab
            try
            {
                tb = (tab)_tabs[_selIndex];
                tb.TouchDown(this, e);
            }
            catch (Exception) { }
        }

        public void TouchUp(object sender, point e)
        {
            if (!visible) return;

            // Check tab buttons
            tab tb;
            for (int i = 0; i < _tabs.Count; i++)
            {
                tb = (tab)_tabs[i];
                if (tb.bounds.contains(e) && _selDown == i)
                {
                    _selIndex = i;
                    _selDown = 0;
                    _parent.Render();
                    Render(true);
                    return;
                }
            }

            // Check Active Tab
            try
            {
                tb = (tab)_tabs[_selIndex];
                tb.TouchUp(this, e);
            }
            catch (Exception) { }
        }

        public void TouchMove(object sender, point e)
        {
            // Check Active Tab
            try
            {
                tab tb = (tab)_tabs[_selIndex];
                tb.TouchUp(this, e);
            }
            catch (Exception) { }
        }

        #endregion

        #region  Properties

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        #endregion

        #region Public Methods

        public void AddTab(tab NewTab)
        {
            NewTab.width = _w - 2;
            NewTab.height = _h - 26;
            NewTab.visible = false;
            NewTab.parent = this;
            NewTab.SetOffset(this, new point(left+ 1, top + 25));
            _tabs.Add(NewTab);
            CalculateTabWidth();
            Render(true);
        }

        public void RemoveTab(tab Tab)
        {
            _tabs.Remove(Tab);
            CalculateTabWidth();
            Render(true);
        }

        public void RemoveTabAt(int Index)
        {
            _tabs.RemoveAt(Index);
            CalculateTabWidth();
            Render(true);
        }

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
            tab tb;
            for (int i = 0; i < _tabs.Count; i++ )
            {
                tb = (tab)_tabs[i];
                tb.SetOffset(this, new point(left + 1, top + 25));
            }
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Draw Outline
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, left, top+ 23, _w, _h - 23, 0, 0, 0, 0, 0, 0, 0, 0, 0);

            // Draw Tabs
            tab tb;
            int x = left;
            int y = top;
            for (int i = 0; i < _tabs.Count; i++)
            {
                tb = (tab)_tabs[i];

                if (tb.enabled)
                {
                    tb.bounds = new rect(x, y, _tabWidth, 24);

                    if (i == _selIndex)
                    {
                        _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, x, y, _tabWidth, 24, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
                        _parent.ScreenBuffer.DrawLine(Colors.LightGray, 1, x + 1, y + 23, x + _tabWidth - 2, y + 23);
                        _parent.ScreenBuffer.DrawTextInRect(tb.Title, x + 2, y + 4, _tabWidth - 4, 20, Bitmap.DT_AlignmentCenter, Colors.Black, FontManager.Tahoma11);
                        tb.visible = true;
                        tb.Render();
                    }
                    else
                    {
                        _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, x, y + 2, _tabWidth, 22, 0, 0, Colors.Wheat, 0, 0, Colors.Wheat, 0, 0, 256);
                        _parent.ScreenBuffer.DrawTextInRect(tb.Title, x + 2, y + 6, _tabWidth - 4, 18, Bitmap.DT_AlignmentCenter, Colors.Gray, FontManager.Tahoma11);
                        tb.visible = false;
                    }

                    x += _tabWidth - 1;
                }
            }

            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

        #region Private Methods

        private void CalculateTabWidth()
        {
            tab tb;
            int mW = 0;
            int tW;
            int tC = 0;

            // Get the longest string width
            for (int i = 0; i < _tabs.Count; i++)
            {
                tb = (tab)_tabs[i];
                if (tb.enabled)
                {
                    tW = FontManager.ComputeExtentEx(FontManager.Tahoma11, tb.Title).width;
                    if (tW > mW) mW = tW;
                    tC++;
                }
            }

            // Determine size
            long TS = ((mW + 10) * tC);
            if (TS < _w)
            {
                _tabWidth = mW + 10; 
            }
            else
            {
                _tabWidth = _w / tC;
            }
        }

        #endregion

    }
}
