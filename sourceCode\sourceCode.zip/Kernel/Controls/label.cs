/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class label : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal PyxisAPI _api;
        protected internal IControl _parent;
        private bool _suspend = false;

        private string _text = "";
        private bool _autosize = true;
        private Font _font = Resources.GetFont(Resources.FontResources.tahoma11);
        private Color _color = Color.Black;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public label(string text, int x, int y)
        {
            _text = text;
            _x = x;
            _y = y;
        }

        public label(string text, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _autosize = false;
        }

        public label(string text, Color ForeColor, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _autosize = false;
        }

        public label(string text, Color ForeColor, Font font, int x, int y, int width, int height)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _font = font;
            _autosize = false;
        }

        public label(string text, Color ForeColor, Font font, int x, int y, int width, int height, bool enabled, bool visible)
        {
            _text = text;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _color = ForeColor;
            _font = font;
            _autosize = false;
            _visible = visible;
            _enabled = enabled;
        }
        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.x - left, e.y - top));
                _mDown = false;
            }
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public string text
        {
            get { return _text; }
            set
            {
                _text = value;
                if (_autosize)
                {
                    if (_parent != null) _parent.Render();
                }
                else
                {
                    Render(true);
                }
            }
        }

        public bool autosize
        {
            get { return _autosize; }
            set
            {
                _autosize = value;
                if (_parent != null) _parent.Render();
            }
        }

        public Font font
        {
            get { return _font; }
            set
            {
                _font = value;
                if (_autosize)
                {
                    if (_parent != null) _parent.Render();
                }
                else
                {
                    Render(true);
                }
            }
        }

        public Color color
        {
            get { return _color; }
            set
            {
                _color = value;
                Render(true);
            }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; if (_parent != null) _parent.Render(); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Public Methods

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion
        
        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            int w = _w;
            int h = _h;

            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Auto-Size first
            if (_autosize) _font.ComputeExtent(_text, out w, out h);

            // Draw String
            _parent.ScreenBuffer.DrawTextInRect(_text, left, top, w, h, Bitmap.DT_AlignmentLeft + Bitmap.DT_WordWrap, _color, _font);

            // Flush if needed
            if (flush) _parent.ScreenBuffer.Flush(left, top, w, h);
        }

        #endregion

    }
}
