/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class checkbox : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private bool _checked = false;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public checkbox(int x, int y)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
        }

        public checkbox(int x, int y, bool selected)
        {
            _x = x;
            _y = y;
            _w = 18;
            _h = 18;
            _checked = selected;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e))
                {
                    if (_enabled)
                    {
                        _checked = !_checked;
                        Render(true);
                    }
                    OnTap(this, new point(e.x - left, e.y - top));
                }
                _mDown = false;
            }
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public bool value
        {
            get { return _checked; }
            set
            {
                _checked = value;
                Render(true);
            }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        #endregion

        #region Public Methods

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            _parent.ScreenBuffer.DrawRectangle((_enabled) ? Color.Black : Colors.DarkGray, 1, left, top, 16, 16, 0,0, (_enabled) ? Colors.White : Colors.Gray, left, top, (_enabled) ? Colors.DarkGray : Colors.Gray, left, top+14, 256);

            if (_checked)
            {
                Color chk = (_enabled) ? Colors.Black : Colors.LightGray;
                _parent.ScreenBuffer.DrawLine(chk, 1, left + 3, top + 3, left + _w - 6, top + _h - 6);
                _parent.ScreenBuffer.DrawLine(chk, 1, left + 3, top + _h - 6, left + _w - 6, top + 3);

                _parent.ScreenBuffer.DrawLine(chk, 1, left + 4, top + 3, left + _w - 6, top + _h - 7);
                _parent.ScreenBuffer.DrawLine(chk, 1, left + 3, top + _h - 7, left + _w - 7, top + 3);

                _parent.ScreenBuffer.DrawLine(chk, 1, left + 3, top + 4, left + _w - 7, top + _h - 6);
                _parent.ScreenBuffer.DrawLine(chk, 1, left + 4, top + _h - 6, left + _w - 6, top + 4);
            }

            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

    }
}
