/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class tab : MarshalByRefObject, IControl, IContainer
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        protected internal bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private Color _bkg = Colors.LightGray;
        private ArrayList _children = new ArrayList();
        private string _title;
        private rect _bounds;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public tab(string title)
        {
            _title = title;
        }

        public tab(string title, Color background)
        {
            _title = title;
            _bkg = background;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            if (!_visible) return;

            // Check controls
            IControl myControl = null;
            for (int i = _children.Count - 1; i >= 0; i--)
            {
                myControl = (IControl)_children[i];
                if (myControl.ScreenBounds.contains(e))
                {
                    myControl.TouchDown(this, e);
                    return;
                }
            }

            _mDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (!_visible) return;

            bool ignoreUp = false;
            bool ret = false;

            // Check controls
            try
            {
                IControl myControl = null;
                for (int i = _children.Count - 1; i >= 0; i--)
                {
                    myControl = (IControl)_children[i];
                    if (myControl.ScreenBounds.contains(e) && !ignoreUp)
                    {
                        myControl.TouchUp(this, e);
                        ret = true;
                        ignoreUp = true;
                    }
                    else if (myControl.PenDown)
                    {
                        myControl.TouchUp(this, e);
                    }
                }
            }
            catch (Exception)
            {
                // just move on
            }

            if (!ret && _mDown) OnTap(this, new point(e.x, e.y - 22));
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public ArrayList Controls
        {
            get { return _children; }
        }

        public Color background
        {
            get { return _bkg; }
            set { _bkg = value; }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return _bounds; }
            internal set { _bounds = value; }
        }

        public IControl parent
        {
            get { return _parent; }
            set 
            {
                if (value is tabdialog)
                {
                    _parent = value;
                }
                else
                    throw new Exception("Tabs can only be added to a TabDialog control.");
            }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Public Methods

        public void addChild(IControl child)
        {
            child.parent = this;
            child.SetOffset(this, new point(left, top));
            _children.Add(child);
        }

        public void removeChild(IControl child)
        {
            _children.Remove(child);
            Render(true);
        }

        public void removeChildAt(int index)
        {
            _children.RemoveAt(index);
            Render(true);
        }

        public void clearChildren()
        {
            _children.Clear();
            Render(true);
        }

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
            for (int i = 0; i < _children.Count; i++)
            {
                IControl ctrl = (IControl)_children[i];
                ctrl.SetOffset(this, new point(left, top));
            }
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            _parent.ScreenBuffer.DrawRectangle(_bkg, 0, left, top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);

            for (int i = 0; i < _children.Count; i++)
            {
                IControl ele = (IControl)_children[i];
                ele.Render();
            }

            if (flush) _parent.APIRef.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

    }
}
