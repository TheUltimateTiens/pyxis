/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;
using System.Threading;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Textbox : Control
    {

        #region Variables

        private string _text = "";
        private bool _multiline = false;
        private Font _font = FontManager.Arial;
        private Color _color = Color.Black;
        private int _caret = 0;
        private bool _showCaret = false;
        private char _pwd = ' ';
        protected internal int _showChar = -1;
        private bool _bReadonly = false;
        private Scrollbar VScroll;

        private string[] _lines;
        Thread thShow;

        #endregion

        #region Events

        public event OnTextChanged TextChanged;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTextChanged(Object sender)
        {
            if (TextChanged != null) TextChanged(sender);
        }

        public event OnVirtualKeyboardClosed VirtualkeyboardClosed;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnVirtualKeyboardClosed(Object sender)
        {
            if (VirtualkeyboardClosed != null) VirtualkeyboardClosed(sender);
        }

        #endregion

        #region Constructors

        public Textbox(string text, int x, int y, int width, int height)
        {
            _text = PyxisAPI.StringReplace(text, "\r", "");
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            PrepControl();
        }

        public Textbox(string text, int x, int y, int width, int height, bool multiline)
        {
            _text = PyxisAPI.StringReplace(text, "\r", "");
            _x = x;
            _y = y;
            _w = width;
            _multiline = multiline;
            if (multiline && height < 40)
                height = 40;
            _h = height;
            PrepControl();
        }

        #endregion

        #region Touch Invokes

        public override void TouchDown(object sender, point e)
        {
            if (_multiline && e.X >= _w - 16)
            {
                VScroll.TouchDown(sender, e);
                return;
            }
            base.TouchDown(sender, e);
        }

        public override void TouchUp(object sender, point e)
        {
            if (!_enabled) return;

            VScroll.TouchUp(sender, e);

            Form frmParent = (Form)_parent.TopLevelContainer;
            if (!_showCaret && frmParent.APIRef.UseVirtualKeyboard && this.ScreenBounds.contains(e) && !_bReadonly)
            {
                createVirtualKeyboard();
            }
        }

        public override void TouchMove(object sender, point e)
        {
            if (_multiline && e.X >= _w - 16)
            {
                VScroll.TouchMove(sender, e);
                return;
            }
        }

        #endregion

        #region  Properties

        public int Caret
        {
            get { return _caret; }
            set
            {
                _caret = value;
                if (_showCaret)
                {
                    if (_multiline && VScroll.Enabled)
                    {
                        size sz = GetCaretSZ();
                        int iY = ((sz.Height + 1) * (_font.Height + 2));
                        
                        if (iY > _h - 4 + VScroll.Value)
                        {
                            VScroll.Value = iY - (_h - 4);
                            return;
                        }

                        if (iY - VScroll.Value < 0)
                        {
                            VScroll.Value = iY - (_h - 4);
                            return;
                        }

                    }

                    Render(true);
                }
            }
        }

        public bool ShowCaret
        {
            get { return _showCaret; }
            set 
            { 
                _showCaret = value; 
                Render(true);
            }
        }

        public string Text
        {
            get { return _text; }
            set
            {
                _text = PyxisAPI.StringReplace(value, "\r", "");
                VScroll.Enabled = false;
                PrepLines();
                Render(true);
                OnTextChanged(this);
            }
        }

        public Font Font
        {
            get { return _font; }
            set
            {
                _font = value;
                VScroll.SmallChange = _font.Height;
                VScroll.LargeChange = _font.Height * 3;
                Render(true);
            }
        }

        public bool Multiline
        {
            get { return _multiline; }
            set
            {
                _multiline = value;
                VScroll.Visible = value;
                if (value && _h < 40)
                    _h = 40;
                Render(true);
            }
        }

        public Color Color
        {
            get { return _color; }
            set { _color = value; }
        }

        public override int Height
        {
            get { return _h; }
            set
            {
                _h = value;
                if (_h < _font.Height + 4 || !_multiline) _h = _font.Height + 4;
                if (_parent != null) _parent.Render();
            }
        }

        public override Control Parent
        {
            get
            {
                return base.Parent;
            }
            set
            {
                base.Parent = value;
                VScroll.Parent = value;
            }
        }

        public char PasswordChar
        {
            get { return _pwd; }
            set 
            {
                _pwd = value;
                PrepLines();
                Render(true);
            }
        }

        internal int ShowChar
        {
            set
            {
                thShow = null;

                if (_pwd == ' ')
                    return;

                _showChar = value;
                PrepLines();
                Render(true);

                if (value > -1)
                {
                    thShow = new Thread(HideCharacters);
                    thShow.Start();
                }
            }
        }

        public bool ReadOnly
        {
            get { return _bReadonly; }
            set { _bReadonly = value; }
        }

        #endregion

        #region Public Methods

        public override void SetOffset(Control sender, point e)
        {
            base.SetOffset(sender, e);
            VScroll.SetOffset(sender, e);
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            _parent.ScreenBuffer.DrawRectangle((_enabled) ? Color.Black : Colors.DarkGray, 1, Left, Top, _w, _h, 0, 0, (_enabled) ? Color.White : Colors.LightGray, 0, 0, (_enabled) ? Color.White : Colors.LightGray, 0, 0, 256);

            rect Region = rect.intersect(new rect(_parent.Left, _parent.Top, _parent.Width, _parent.Height), new rect(Left + 1, Top + 1, _w - 2, _h - 2));
            _parent.ScreenBuffer.SetClippingRectangle(Region.X, Region.Y, Region.Width, Region.Height);

            int y = (Top + 2) - VScroll.Value;
            int x = Left + 2;
            int x2;
            string sLine;
            Color col = (_enabled) ? _color : Colors.Gray;

            if (_lines != null)
            {

                if (_caret > _text.Length) _caret = _text.Length;
                size szCaret = (_showCaret) ? GetCaretSZ() : new size(-1, -1);

                for (int i = 0; i < _lines.Length; i++)
                {
                    sLine = _lines[i].TrimEnd('\n');
                    _parent.ScreenBuffer.DrawText(sLine, _font, col, x, y);

                    if (i == szCaret.Height)
                    {
                        x2 = Left + 2 + FontManager.ComputeExtentEx(_font, _lines[i].Substring(0, szCaret.Width)).Width;
                        _parent.ScreenBuffer.DrawLine(Colors.Blue, 1, x2, y, x2, y + _font.Height);
                    }

                    y += _font.Height + 2;
                    if (!_multiline)
                        break;
                }
            }
            else if (_showCaret)
            {
                x2 = Left + 2;
                _parent.ScreenBuffer.DrawLine(Colors.Blue, 1, x2, y, x2, y + _font.Height);
            }

            if (_multiline)
                VScroll.Render(false);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        private size GetCaretSZ()
        {

            if (_lines == null)
                return new size(-1, -1);

            int iLine = -1;
            int iRem = _caret;

            while (true)
            {
                iLine++;

                int iLen = _lines[iLine].Length;
                if (iLen == 0)
                    iLen = 1;
                if (iRem - iLen <= 0 || iRem == 1)
                {
                    if (_lines[iLine].Substring(iRem - 1, 1) == "\n")
                    {
                        return new size(0, iLine + 1);
                    }
                    else
                        return new size(iRem, iLine);
                }
                else
                    iRem = iRem - iLen;
            }

        }

        private string pwdString()
        {
            string strOut = string.Empty;

            if (_showChar == -1)
            {
                for (int i = 0; i < _text.Length; i++)
                    strOut += _pwd;
            }
            else
            {
                for (int i = 0; i < _showChar; i++)
                    strOut += _pwd;

                strOut += _text.Substring(_showChar, 1);

                for (int i = _showChar + 1; i < _text.Length; i++)
                    strOut += _pwd;

            }
            return strOut;
        }

        private void PrepLines()
        {
            // Clear out Lines
            _lines = null;

            // Leave if no text
            if (_text == string.Empty)
                return;

            // Prep Variables
            int maxX = (_multiline) ? _w - 20 : _w - 2;
            int x = 4;
            int w;
            string sText = (_pwd == ' ') ? _text : pwdString();
            int iNextLine, iNext;
            int iStart = 0;
            string sOut = string.Empty;
            string sWord;
            int spWidth = FontManager.ComputeExtentEx(_font, " ").Width;
            bool bMustRet = false;

            // Prepare Lines
            while (sText != string.Empty)
            {
                iNext = sText.IndexOf(' ', iStart);                 // Get the next space
                iNext = (iNext < 0) ? sText.Length : iNext + 1;     // Adjust to include space or be end of line

                // Check for a return
                iNextLine = sText.IndexOf('\n', iStart);
                if (iNextLine > -1 && iNextLine <= iNext)
                {
                    iNext = iNextLine + 1;                          // Return comes first, use that
                    bMustRet = true;
                }

                sWord = sText.Substring(0, iNext);

                w = FontManager.ComputeExtentEx(_font, sWord).Width;
                if (x + w > maxX)
                {
                    if (sOut != string.Empty)
                    {
                        // Check if the "word" can fit on a line by itself
                        if (4 + w > maxX)
                        {
                            sWord = FixLongWord(sWord, x, maxX);
                            sOut += sWord;
                        }

                        AddLine(sOut);
                        sText = sText.Substring(sOut.Length);
                        sOut = string.Empty;
                        x = 4;
                    }
                    else
                    {
                        sOut = FixLongWord(sWord, 4, maxX);
                        AddLine(sOut);
                        sText = sText.Substring(sOut.Length);
                        sOut = string.Empty;
                        x = 4;
                    }
                }
                else
                {
                    sOut += sWord;
                    sText = sText.Substring(sWord.Length);
                    x += w;
                }

                if (bMustRet)
                {
                    AddLine(sOut);
                    sOut = string.Empty;
                    bMustRet = false;
                    x = 4;
                }

            }

            // Add any remaining text to a new line
            AddLine(sOut);

            // Prep Scroll
            if (_lines.Length * (_font.Height + 2) > _h - 4)
            {
                VScroll.Enabled = true;
                VScroll.Maximum = (_lines.Length * (_font.Height + 2)) - (_h - 4);
            }
        }

        private string FixLongWord(string word, int x, int maxX)
        {
            while (FontManager.ComputeExtentEx(_font, word).Width + x > maxX)
            {
                int s = word.Length - 1;
                while (FontManager.ComputeExtentEx(_font, word).Width + x > maxX)
                {
                    s--;
                    word = word.Substring(0, s);
                }

                return word;
            }

            return word;
        }

        private void AddLine(string line)
        {
            if (_lines == null)
            {
                _lines = new string[1] { line };
            }
            else
            {
                string[] _temp = new string[_lines.Length + 1];
                Array.Copy(_lines, _temp, _lines.Length);
                _temp[_temp.Length-1] = line;
                _lines = _temp;
            }
        }

        private void PrepControl()
        {
            VScroll = new Scrollbar(_x + _w - 16, _y, _h, Orientation.Vertical);
            VScroll.Visible = false;
            VScroll.Enabled = false;
            VScroll.SmallChange = _font.Height;
            VScroll.LargeChange = _font.Height * 3;
            VScroll.ValueChanged += new OnValueChanged(VScroll_ValueChanged);
            VScroll.AutoRepeating = false;
            PrepLines();
        }

        private void HideCharacters()
        {
            Thread.Sleep(750);
            ShowChar = -1;
        }

        #endregion

        #region Events

        private void VScroll_ValueChanged(object sender, int value)
        {
            Render(true);
        }

        #endregion

        #region Virtual Keyboard

        private Form frmVKey;
        private int iStartY;
        private Panel vpane;
        private Textbox txt1;
        private CommandButton btnDone;
        private CommandButton btnLeft;
        private CommandButton btnRight;
        private Form prvActive;

        private void createVirtualKeyboard()
        {
            Form frmParent = (Form)_parent.TopLevelContainer;
            prvActive = frmParent.APIRef.ActiveForm;

            Font fnt = FontManager.ArialBold;

            frmVKey = new Form(frmParent.APIRef, ColorUtility.ColorFromRGB(241, 241, 241), true, true);

            txt1 = new Textbox(_text, 0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight - 189);
            txt1.Caret = txt1.Text.Length;
            txt1.Multiline = _multiline;
            txt1.PasswordChar = _pwd;
            txt1.ShowCaret = true;
            frmVKey.AddChild(txt1);

            vpane = new Panel(0, AppearanceManager.ScreenHeight - 167 - 22, AppearanceManager.ScreenWidth, 167);
            vpane.Background = ColorUtility.ColorFromRGB(226, 226, 226);
            frmVKey.AddChild(vpane);

            btnDone = new CommandButton("Done", AppearanceManager.ScreenWidth - 78, 4);
            btnDone.tapEvent += new OnTap((object sender, point e) => bindDone());
            btnDone.Font = fnt;
            vpane.AddChild(btnDone);

            btnLeft = new CommandButton("<|", 4, btnDone.Y, 25, 25);
            btnLeft.tapEvent += new OnTap((object sender, point e) => bindLeft());
            btnLeft.Font = fnt;
            vpane.AddChild(btnLeft);

            btnRight = new CommandButton("|>", 32, btnDone.Y, 25, 25);
            btnRight.tapEvent += new OnTap((object sender, point e) => bindRight());
            btnRight.Font = fnt;
            vpane.AddChild(btnRight);

            updateLR();

            iStartY = btnDone.Y + 37;
            createNormalKeys(false);

            frmParent.APIRef.ActiveForm = frmVKey;
        }

        private void bindDone()
        {
            if (_text != txt1.Text)
            {
                Text = txt1.Text;
                OnTextChanged(this);
            }
            txt1.Parent = null;
            Form frmParent = (Form)_parent.TopLevelContainer;
            frmParent.APIRef.ActiveForm = prvActive;
            frmVKey = null;
            vpane = null;
            txt1 = null;
            btnDone = null;
            btnLeft = null;
            btnRight = null;
            OnVirtualKeyboardClosed(txt1);
        }

        private void destroyKeys()
        {
            vpane.Suspended = true;
            vpane.ClearChildren();
        }

        private void bindBackspace()
        {
            txt1.Suspended = true;
            int iCaret = txt1.Caret;
            txt1.Text = txt1.Text.Substring(0, txt1.Caret - 1) + txt1.Text.Substring(txt1.Caret);
            if (txt1.Caret == iCaret) txt1.Caret--;
            txt1.Suspended = false;
            updateLR();
        }

        private void bindKey(CommandButton btn, CommandButton btnShift)
        {
            string strMid = (btnShift.Color == Colors.Blue) ? btn.Text : btn.Text.ToLower();
            string strLeft = txt1.Text.Substring(0, txt1.Caret);
            string strRight = txt1.Text.Substring(txt1.Caret);
            txt1.Suspended = true;
            txt1.Text = strLeft + strMid + strRight;
            txt1.Caret++;
            txt1.ShowChar = strLeft.Length;
            txt1.Suspended = false;
            updateLR();
        }

        private void bindKey2(CommandButton btn)
        {
            txt1.Suspended = true;
            txt1.Text = txt1.Text.Substring(0, txt1.Caret) + btn.Text + txt1.Text.Substring(txt1.Caret);
            txt1.Caret++;
            txt1.ShowChar = txt1.Caret - 1;
            txt1.Suspended = false;
            updateLR();
        }

        private void bindKeyChar(string str)
        {
            txt1.Suspended = true;
            txt1.Text = txt1.Text.Substring(0, txt1.Caret) + str + txt1.Text.Substring(txt1.Caret);
            txt1.Caret++;
            txt1.ShowChar = txt1.Caret - 1;
            txt1.Suspended = false;
            updateLR();
        }

        private void bindLeft()
        {
            if (txt1.Caret > 0) txt1.Caret--;
            updateLR();
        }

        private void bindRight()
        {
            if (txt1.Caret < txt1.Text.Length) txt1.Caret++;
            updateLR();
        }

        private void updateLR()
        {
            btnRight.Enabled = (txt1.Caret < txt1.Text.Length);
            btnLeft.Enabled = (txt1.Caret > 0);
        }

        private void createNormalKeys(bool clearKeys)
        {
            Font fnt = FontManager.ArialBold;
            CommandButton btnShift = null;

            if (clearKeys)
            {
                destroyKeys();
                vpane.AddChild(btnDone);
                vpane.AddChild(btnLeft);
                vpane.AddChild(btnRight);
            }

            // Row 1
            string[] letters = { "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P" };
            int y = iStartY;
            int x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int farLeft = x;
            int i;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey(btn, btnShift));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 2
            letters = new string[] { "A", "S", "D", "F", "G", "H", "J", "K", "L" };
            y = iStartY + 30;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey(btn, btnShift));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 3
            letters = new string[] { "Z", "X", "C", "V", "B", "N", "M" };
            y = iStartY + 60;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int nearLeft = x + 28;
            int sbW = x - farLeft - 3;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey(btn, btnShift));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Special Keys
            btnShift = new CommandButton("Shft", farLeft, y, sbW, 25);
            btnShift.tapEvent += new OnTap((object sender, point e) => btnShift.Color = (btnShift.Color == Colors.Blue) ? Color.Black : Colors.Blue);
            btnShift.Font = fnt;
            vpane.AddChild(btnShift);

            CommandButton btnBckSpc = new CommandButton("BSpc", x, y, sbW, 25);
            btnBckSpc.tapEvent += new OnTap((object sender, point e) => bindBackspace());
            btnBckSpc.Font = fnt;
            vpane.AddChild(btnBckSpc);

            y += 30;
            CommandButton btnSpace = new CommandButton(" ", nearLeft, y, (5 * 28) - 3, 25);
            btnSpace.tapEvent += new OnTap((object sender, point e) => bindKeyChar(" "));
            vpane.AddChild(btnSpace);

            CommandButton btnNums = new CommandButton(".?123", farLeft, y, nearLeft - farLeft - 3, 25);
            btnNums.tapEvent += new OnTap((object sender, point e) => createNumberKeys());
            btnNums.Font = fnt;
            vpane.AddChild(btnNums);

            CommandButton btnRet = new CommandButton("Retr", btnSpace.X + btnSpace.Width + 3, y, btnNums.Width, 25);
            btnRet.tapEvent += new OnTap((object sender, point e) => bindKeyChar("\n"));
            btnRet.Font = fnt;
            btnRet.Enabled = txt1.Multiline;
            vpane.AddChild(btnRet);

            if (clearKeys) vpane.Suspended = false;
        }

        private void createNumberKeys()
        {
            Font fnt = FontManager.ArialBold;

            destroyKeys();

            vpane.AddChild(btnDone);
            vpane.AddChild(btnLeft);
            vpane.AddChild(btnRight);

            // Row 1
            string[] letters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            int y = iStartY;
            int x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int farLeft = x;
            int i;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 2
            letters = new string[] { "-", "/", ":", ";", "(", ")", "$", "&" };
            y = iStartY + 30;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 3
            letters = new string[] { ".", ",", "?", "!", "@", "\"", "'" };
            y = iStartY + 60;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int nearLeft = x + 28;
            int sbW = x - farLeft - 3;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }


            // Special Keys
            CommandButton btnShift = new CommandButton("#+=", farLeft, y, sbW, 25);
            btnShift.tapEvent += new OnTap((object sender, point e) => createMathKeys());
            btnShift.Font = fnt;
            vpane.AddChild(btnShift);

            CommandButton btnBckSpc = new CommandButton("BSpc", x, y, sbW, 25);
            btnBckSpc.tapEvent += new OnTap((object sender, point e) => bindBackspace());
            btnBckSpc.Font = fnt;
            vpane.AddChild(btnBckSpc);

            y += 30;
            CommandButton btnSpace = new CommandButton(" ", nearLeft, y, (5 * 28) - 3, 25);
            btnSpace.tapEvent += new OnTap((object sender, point e) => bindKeyChar(" "));
            vpane.AddChild(btnSpace);

            CommandButton btnNums = new CommandButton("ABC", farLeft, y, nearLeft - farLeft - 3, 25);
            btnNums.tapEvent += new OnTap((object sender, point e) => createNormalKeys(true));
            btnNums.Font = fnt;
            vpane.AddChild(btnNums);

            CommandButton btnRet = new CommandButton("Retr", btnSpace.X + btnSpace.Width + 3, y, btnNums.Width, 25);
            btnRet.tapEvent += new OnTap((object sender, point e) => bindKeyChar("\n"));
            btnRet.Font = fnt;
            btnRet.Enabled = txt1.Multiline;
            vpane.AddChild(btnRet);

            vpane.Suspended = false;
        }

        private void createMathKeys()
        {
            Font fnt = FontManager.ArialBold;

            destroyKeys();

            vpane.AddChild(btnDone);
            vpane.AddChild(btnLeft);
            vpane.AddChild(btnRight);

            // Row 1
            string[] letters = { "[", "]", "{", "}", "#", "%", "^", "*", "+", "=" };
            int y = iStartY;
            int x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int farLeft = x;
            int i;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 2
            letters = new string[] { "_", "\\", "|", "~", "<", ">", "`", ":" };
            y = iStartY + 30;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }

            // Row 3
            letters = new string[] { ".", ",", "?", "!", "$", "�", "�" };
            y = iStartY + 60;
            x = (int)((AppearanceManager.ScreenWidth - (28 * letters.Length)) / 2);
            int nearLeft = x + 28;
            int sbW = x - farLeft - 3;
            for (i = 0; i < letters.Length; i++)
            {
                CommandButton btn = new CommandButton(letters[i], x, y, 25, 25);
                btn.tapEvent += new OnTap((object sender, point e) => bindKey2(btn));
                btn.Font = fnt;
                vpane.AddChild(btn);
                x += 28;
            }


            // Special Keys
            CommandButton btnShift = new CommandButton(".?123", farLeft, y, sbW, 25);
            btnShift.tapEvent += new OnTap((object sender, point e) => createNumberKeys());
            btnShift.Font = fnt;
            vpane.AddChild(btnShift);

            CommandButton btnBckSpc = new CommandButton("BSpc", x, y, sbW, 25);
            btnBckSpc.tapEvent += new OnTap((object sender, point e) => bindBackspace());
            btnBckSpc.Font = fnt;
            vpane.AddChild(btnBckSpc);

            y += 30;
            CommandButton btnSpace = new CommandButton(" ", nearLeft, y, (5 * 28) - 3, 25);
            btnSpace.tapEvent += new OnTap((object sender, point e) => bindKeyChar(" "));
            vpane.AddChild(btnSpace);

            CommandButton btnNums = new CommandButton("ABC", farLeft, y, nearLeft - farLeft - 3, 25);
            btnNums.tapEvent += new OnTap((object sender, point e) => createNormalKeys(true));
            btnNums.Font = fnt;
            vpane.AddChild(btnNums);

            CommandButton btnRet = new CommandButton("Retr", btnSpace.X + btnSpace.Width + 3, y, btnNums.Width, 25);
            btnRet.tapEvent += new OnTap((object sender, point e) => bindKeyChar("\n"));
            btnRet.Font = fnt;
            btnRet.Enabled = txt1.Multiline;
            vpane.AddChild(btnRet);

            vpane.Suspended = false;
        }

        #endregion

    }

}
