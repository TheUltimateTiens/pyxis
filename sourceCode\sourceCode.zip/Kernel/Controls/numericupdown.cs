/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;
using System.Threading;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class numericupdown : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private int _min = 0;
        private int _max = 100;
        private int _val = 0;
        private bool _force = false;
        private int _chgVal;
        private Thread _changer;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public numericupdown(int x, int y, int width, int minimum, int maximum)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = 20;
            _max = maximum;
            _min = minimum;
        }

        public numericupdown(int x, int y, int width, int minimum, int maximum, int value)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = 20;
            _max = maximum;
            _min = minimum;
            _val = value;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mDown = true;

            if (!_enabled) return;
            if (new rect(left + _w - 16, top, 16, 10).contains(e))
            {
                value = _val + 1;
                _chgVal = 1;
                _changer = new Thread(AutoIncDec);
                _changer.Priority = ThreadPriority.AboveNormal;
                _changer.Start();
                return;
            }

            if (new rect(left + _w - 16, top + 10, 16, 10).contains(e))
            {
                value = _val - 1;
                _chgVal = -1;
                _changer = new Thread(AutoIncDec);
                _changer.Priority = ThreadPriority.AboveNormal;
                _changer.Start();
                return;
            }

        }

        public void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.x - left, e.y - top));
                _mDown = false;
            }
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public bool forceZeros
        {
            get { return _force; }
            set { _force = value; }
        }

        public int minimum
        {
            get { return _min; }
            set
            {
                if (value >= _max) value = _max - 1;
                _min = value;
                Render(true);
            }
        }

        public int maximum
        {
            get { return _max; }
            set
            {
                if (value <= _min) value = _min + 1;
                _max = value;
                Render(true);
            }
        }

        public int value
        {
            get { return _val; }
            set
            {
                if (value < _min) value = _min;
                if (value > _max) value = _max;
                _val = value;
                Render(true);
            }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                _parent.Render();
            }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        #endregion

        #region Public Methods

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, left, top, _w + 1, 21, 0, 0, (_enabled) ? Colors.White : Colors.LightGray, 0, 0, (_enabled) ? Colors.White : Colors.LightGray, 0, 0, 256);
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, left + _w - 16, top, 17, 21, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
            _parent.ScreenBuffer.DrawLine(Colors.Black, 1, left + _w - 15, top + 10, left + _w, top + 10);
            _parent.ScreenBuffer.DrawImage(left + _w - 12, top + 3, Resources.GetBitmap(Resources.BitmapResources.up), 0, 0, 9, 5);
            _parent.ScreenBuffer.DrawImage(left + _w - 12, top  + 13, Resources.GetBitmap(Resources.BitmapResources.down), 0, 0, 9, 5);

            _parent.ScreenBuffer.DrawTextInRect((_force) ? IntToNString(value,maximum.ToString().Length) : value.ToString(), left + 1, top + 2, _w - 18, 16, Bitmap.DT_AlignmentRight, (_enabled) ? Colors.Black : Colors.Gray, FontManager.Tahoma11);

            if (flush) _parent.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

        #region Private Methods

        private void AutoIncDec()
        {
            int iWait = 750;
            while (_mDown)
            {
                Thread.Sleep(iWait);
                if (!_mDown) return;
                value = _val + _chgVal;
                switch (iWait)
                {
                    case 750:
                        iWait = 500;
                        break;
                    case 500:
                        iWait = 250;
                        break;
                    case 250:
                        iWait = 75;
                        break;
                }
            }
        }

        private string IntToNString(int value, int len)
        {
            string val = value.ToString();
            if (val.Length >= len) return val;

            while (val.Length < len)
                val = "0" + val;

            return val;
        }

        #endregion

    }
}
