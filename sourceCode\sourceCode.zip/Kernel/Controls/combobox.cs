/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{

    [Serializable]
    public class Combobox : Control
    {

        #region Variables

        private ArrayList _items = new ArrayList();
        private int _selIndex = -1;
        private Font _font = FontManager.Arial;

        #endregion

        #region Events

        public event OnSelectedIndexChange SelectedIndexChanged;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnSelectedIndexChange(Object sender, int e)
        {
            if (SelectedIndexChanged != null) SelectedIndexChanged(sender, e);
        }

        #endregion

        #region Constructors

        public Combobox(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

        public Combobox(int x, int y, int width, int height, string[] items)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            for (int i = 0; i < items.Length; i++)
            {
                _items.Add(items[i]);
            }
            if (items != null) _selIndex = 0;
        }

        #endregion

        #region Touch Invokes

        public override void TouchUp(object sender, point e)
        {
            if (_mDown && this.ScreenBounds.contains(e))
            {
                if (_enabled && _items.Count > 0) 
                    showListbox();
                _mDown = false;
            }
        }

        #endregion

        #region  Properties

        public int SelectedIndex
        {
            get { return _selIndex; }
            set
            {
                if (_selIndex == value) return;
                _selIndex = value;
                Render(true);
                OnSelectedIndexChange(this, value);
            }
        }

        public string SelectedItem
        {
            get
            {
                if (_items.Count == 0 || _selIndex < 0) return "";
                return (string)_items[_selIndex];
            }
        }
        
        #endregion

        #region Public Methods

        public void AddItem(string text)
        {
            _items.Add(text);
            if (_selIndex < 0) _selIndex = 0;
            Render(true);
        }

        public void RemoveItem(string text)
        {
            _items.Remove(text);
            if (_selIndex > _items.Count) _selIndex = _items.Count;
            Render(true);
        }

        public void RemoveItemAt(int index)
        {
            _items.RemoveAt(index);
            if (_selIndex > _items.Count) _selIndex = _items.Count;
            Render(true);
        }

        #endregion

        #region GUI

        public override void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
            _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

            //Draw the outline
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, Left, Top, _w - 2, _h, 0, 0, Colors.White, 0, 0, Colors.White, 0, 0, 256);

            // Draw the CommandButton
            int btnLeft = Left + _w - 20;
            Color back1 = ColorUtility.ColorFromRGB(242, 242, 242);
            Color back2 = ColorUtility.ColorFromRGB(207, 207, 207);
            _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, btnLeft, Top, 20, _h, 1, 1, Color.Black, 0, 0, Color.Black, 0, 0, 0);
            _parent.ScreenBuffer.DrawRectangle(Color.White, 1, btnLeft + 1, Top + 1, 18, _h - 2, 0, 0, back1, 0, 0, back1, 0, 0, 256);
            if (_items.Count > 0)
            {
                _parent.ScreenBuffer.DrawRectangle(Color.White, 0, btnLeft + 2, Top + (_h / 2), 16, (_h / 2) - 1, 0, 0, back2, 0, 0, back2, 0, 0, 256);
                _parent.ScreenBuffer.DrawImage(btnLeft + 6, Top + 8, Resources.GetBitmap(Resources.BitmapResources.down), 0, 0, 9, 5);
            }

            // Draw the text
            _parent.ScreenBuffer.DrawTextInRect(SelectedItem, Left + 3, Top + 2, _w - 22, _h - 4, Bitmap.DT_AlignmentLeft + Bitmap.DT_TrimmingNone, (_enabled) ? Colors.Black : Colors.DarkGray, _font);

            if (flush)
            {
                _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            }
        }

        #endregion

        #region Item Selection

        Form prv = null;

        private void showListbox()
        {
            // Blackout the screen
            _parent.ScreenBuffer.DrawRectangle(Color.Black, 0, 0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight, 0, 0, Color.Black, 0, 0, Color.Black, 0, 0, 100);
            _parent.ScreenBuffer.Flush();

            // Calculate the Form height
            int h = (_items.Count * 32) + 41;
            if (h > AppearanceManager.ScreenHeight - 20) h = AppearanceManager.ScreenHeight - 20;

            // Calculate the Y
            int dY = (int)((float)AppearanceManager.ScreenHeight / 2) - (h / 2);

            // Create the Form
            Form frmParent = (Form)_parent.TopLevelContainer;
            Form frmSel = new Form(frmParent.APIRef, Colors.LightGray, 10, dY, AppearanceManager.ScreenWidth - 25, h, true, true, Form.WindowType.container);
            Listbox lst1 = new Listbox(6, 6, frmSel.Width - 12, frmSel.Height - 39);
            CommandButton btn1 = new CommandButton("Done", frmSel.Width - 81, frmSel.Height - 31);
            btn1.tapEvent += new OnTap((object sender, point e) =>  hideListbox(lst1));
            for (int i = 0; i < _items.Count; i++) lst1.AddItem((string)_items[i]);
            lst1.SelectedIndex = _selIndex;
            frmSel.AddChild(lst1);
            frmSel.AddChild(btn1);

            // Prep for display
            _parent.ScreenBuffer.Flush();
            prv = frmParent.APIRef.ActiveForm;
            frmParent.APIRef.ActiveForm = frmSel;

        }

        private void hideListbox(Listbox lst)
        {
            Form frmParent = (Form)_parent.TopLevelContainer;
            SelectedIndex = lst.SelectedIndex;
            frmParent.APIRef.ActiveForm = prv;
            prv = null;
            frmParent.APIRef.desktop.Render(true);
        }

        #endregion

    }

}
