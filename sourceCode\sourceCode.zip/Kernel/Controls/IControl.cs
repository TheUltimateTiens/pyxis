/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation.Media;

using Skewworks.Pyxis.GUI.Controls;

namespace Skewworks.Pyxis.Kernel
{

    [Serializable]
    public delegate void OnTap(object sender, point e);

    [Serializable]
    public delegate void OnFormTap(point e);

    [Serializable]
    public delegate void OnNodeTap(treeviewnode node, point e);

    [Serializable]
    public delegate void OnNodeExpanded(object sender, treeviewnode node);

    [Serializable]
    public delegate void OnNodeCollapsed(object sender, treeviewnode node);

    [Serializable]
    public delegate void OnSelectedIndexChange(object sender, int index);

    [Serializable]
    public delegate void OnSelectedFileChanged(object sender, string path);

    [Serializable]
    public delegate void OnTextChanged(object sender);

    [Serializable]
    public delegate void OnVirtualKeyboardClosed(object sender);
    
    public interface IControl
    {

        #region Properties

        int x
        {
            get;
            set;
        }

        int y
        {
            get;
            set;
        }

        int width
        {
            get;
            set;
        }

        int height
        {
            get;
            set;
        }

        int top
        {
            get;
        }

        int left
        {
            get;
        }

        bool enabled
        {
            get;
            set;
        }

        bool visible
        {
            get;
            set;
        }

        bool PenDown
        {
            get;
        }

        bool suspended
        {
            get;
            set;
        }

        rect ScreenBounds
        {
            get;
        }

        IControl parent
        {
            get;
            set;
        }

        PyxisAPI APIRef
        {
            get;
        }

        Bitmap ScreenBuffer
        {
            get;
        }

        #endregion

        #region Methods

        void Render();
        void SetOffset(IControl sender, point e);
        void TouchDown(object sender, point e);
        void TouchUp(object sender, point e);
        void TouchMove(object sender, point e);

        #endregion

    }

}
