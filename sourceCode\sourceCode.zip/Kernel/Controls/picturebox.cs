/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT.Touch;

using Skewworks.Pyxis.Kernel;

namespace Skewworks.Pyxis.GUI.Controls
{
    public class picturebox : MarshalByRefObject, IControl
    {

        #region Variables

        protected internal int _xOffset;        // Used for placement inside containers like forms & panels
        protected internal int _yOffset;        // Used for placement inside containers like forms & panels

        protected internal int _x;
        protected internal int _y;
        protected internal int _w;
        protected internal int _h;
        protected internal bool _visible = true;
        protected internal bool _enabled = true;
        private bool _mDown = false;
        protected internal IControl _parent;
        private bool _suspend = false;

        private ScaleMode _scale = ScaleMode.Normal;
        private bool _autosize = true;
        private BorderStyle _border = BorderStyle.Border3D;
        private Color _bkg = Colors.DarkGray;
        private Bitmap _bmp = null;

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(Object sender, point e)
        {
            if (tapEvent != null) tapEvent(sender, e);
        }

        #endregion

        #region Constructors

        public picturebox(Bitmap image, int x, int y)
        {
            _bmp = image;
            _x = x;
            _y = y;
        }

        public picturebox(Bitmap image, int x, int y, int width, int height)
        {
            _bmp = image;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _autosize = false;
        }

        public picturebox(Bitmap image, int x, int y, int width, int height, BorderStyle border, ScaleMode scale)
        {
            _bmp = image;
            _x = x;
            _y = y;
            _w = width;
            _h = height;
            _autosize = false;
            _border = border;
            _scale = scale;
        }

        #endregion

        #region Touch Invokes

        public void TouchDown(object sender, point e)
        {
            _mDown = true;
        }

        public void TouchUp(object sender, point e)
        {
            if (_mDown)
            {
                if (this.ScreenBounds.contains(e)) OnTap(this, new point(e.x - left, e.y - top));
                _mDown = false;
            }
        }

        public void TouchMove(object sender, point e)
        {
            // Do nothing
        }

        #endregion

        #region  Properties

        public bool autosize
        {
            get { return _autosize; }
            set { _autosize = value; Render(true); }
        }

        public Color background
        {
            get { return _bkg; }
            set { _bkg = value; Render(true); }
        }

        public ScaleMode scalemode
        {
            get { return _scale; }
            set { _scale = value; Render(true); }
        }

        public BorderStyle borderstyle
        {
            get { return _border; }
            set { _border = value; Render(true); }
        }

        public Bitmap image
        {
            get { return _bmp; }
            set { _bmp = value; Render(true); }
        }

        public int x
        {
            get { return _x; }
            set { _x = value; if (_parent != null) _parent.Render(); }
        }

        public int y
        {
            get { return _y; }
            set { _y = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int width
        {
            get { return _w; }
            set { _w = value; if (_parent != null) _parent.Render(); }
        }

        public virtual int height
        {
            get { return _h; }
            set
            {
                if (value < 30) value = 30;
                _h = value;
                if (_parent != null) _parent.Render();
            }
        }

        public bool visible
        {
            get { return _visible; }
            set { _visible = value; Render(true); }
        }

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; Render(true); }
        }

        public rect bounds
        {
            get { return new rect(_x, _y, _w, _h); }
        }

        public IControl parent
        {
            get { return _parent; }
            set { _parent = value; }
        }

        public rect ScreenBounds
        {
            get { return new rect(_x + _xOffset, _y + _yOffset, _w, _h); }
        }

        public bool suspended
        {
            get { return _suspend; }
            set
            {
                _suspend = value;
                if (!_suspend && _parent != null) _parent.Render();
            }
        }

        public int top
        {
            get { return _y + _yOffset; }
        }

        public int left
        {
            get { return _x + _xOffset; }
        }

        public bool PenDown
        {
            get { return _mDown; }
        }

        public PyxisAPI APIRef
        {
            get { return _parent.APIRef; }
        }

        public Bitmap ScreenBuffer
        {
            get { return (_parent == null) ? null : _parent.ScreenBuffer; }
        }

        #endregion

        #region Public Methods

        public void SetOffset(IControl sender, point e)
        {
            if (sender != parent) throw new Exception("Only a parent can set a child's offset");
            _xOffset = e.x;
            _yOffset = e.y;
        }

        #endregion

        #region GUI

        public void Render()
        {
            Render(false);
        }

        private void Render(bool flush)
        {
            if (_parent == null || _parent.ScreenBuffer == null || !_visible || _suspend) return;

            // Get Border offset
            int bOffset = 0;
            switch (_border)
            {
                case BorderStyle.Border3D:
                    bOffset = 2;
                    break;
                case BorderStyle.BorderFlat:
                    bOffset = 1;
                    break;
            }

            // Check auto-size first
            if (_autosize)
            {
                _w = _bmp.Width + bOffset + bOffset;
                _h = _bmp.Height + bOffset + bOffset;
            }

            // Render border & background
            switch (_border)
            {
                case BorderStyle.Border3D:
                    _parent.ScreenBuffer.DrawRectangle(Colors.White, 1, left, top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);
                    _parent.ScreenBuffer.DrawRectangle(Colors.Gray, 0, left + 1, top + 1, _w - 2, _h - 2, 0, 0, Colors.Gray, 0, 0, Colors.Gray, 0, 0, 256);
                    break;
                case BorderStyle.BorderFlat:
                    _parent.ScreenBuffer.DrawRectangle(Colors.Black, 1, left, top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);
                    break;
                case BorderStyle.BorderNone:
                    _parent.ScreenBuffer.DrawRectangle(_bkg, 0, left, top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);
                    break;
            }

            // Render Image
            if (_bmp != null)
            {
                switch (_scale)
                {
                    case ScaleMode.Normal:
                        _parent.ScreenBuffer.SetClippingRectangle(left + bOffset, top + bOffset, _w - bOffset - bOffset, _h - bOffset - bOffset);
                        _parent.ScreenBuffer.DrawImage(left + bOffset, top + bOffset, _bmp, 0, 0, _bmp.Width, _bmp.Height);
                        _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
                        break;
                    case ScaleMode.Stretch:
                        _parent.ScreenBuffer.DrawImage(left + bOffset, top + bOffset, _bmp, 0, 0, _w - bOffset - bOffset, _h - bOffset - bOffset);
                        break;
                    case ScaleMode.Scale:
                        float multiplier;
                        int dH = _h - bOffset - bOffset;
                        int dW = _w - bOffset - bOffset;


                        if (_bmp.Height > _bmp.Width)
                        {
                            // Portrait
                            if (dH > dW)
                            {
                                multiplier = (float)dW / (float)_bmp.Width;
                            }
                            else
                            {
                                multiplier = (float)dH / (float)_bmp.Height;
                            }
                        }
                        else
                        {
                            // Landscape
                            if (dH > dW)
                            {
                                multiplier = (float)dW / (float)_bmp.Width;
                            }
                            else
                            {
                                multiplier = (float)dH / (float)_bmp.Height;
                            }
                        }

                        int dsW = (int)((float)_bmp.Width * multiplier);
                        int dsH = (int)((float)_bmp.Height * multiplier);
                        int dX = left + bOffset + (int)((float)dW / 2 - (float)dsW / 2);
                        int dY = top + bOffset + (int)((float)dH / 2 - (float)dsH / 2);

                        _parent.ScreenBuffer.SetClippingRectangle(left + bOffset, top + bOffset, _w - bOffset - bOffset, _h - bOffset - bOffset);
                        _parent.ScreenBuffer.DrawImage(dX, dY, _bmp, 0, 0, dsW, dsH);
                        _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
                        break;
                }
            }

            if (flush) _parent.APIRef.ScreenBuffer.Flush(left, top, _w, _h);
        }

        #endregion

    }
}
