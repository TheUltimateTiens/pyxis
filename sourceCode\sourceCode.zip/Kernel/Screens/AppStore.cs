/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Threading;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation.Media;

using GHIElectronics.NETMF.Hardware;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.GUI.Controls;

namespace Skewworks.Pyxis.Kernel
{
    class AppStore
    {
        #region Variables

        private static PyxisAPI API;
        private static bool bLoaded = false;
        private static MenuItem AppMenu = null;
        private static Form frmMain = null;
        private static Form frmInfo = null;
        private static MenuItem mnuQuitApp;
        private static MenuItem mnuSwitchToApp;
        private static Bitmap buffer2 = null;
        private static ImageListbox ILB;
        private static string _search;
        private static Thread _searchThread;
        private static ModalMessage MM;
        
        #endregion

        #region Public Methods

        public static void Show(PyxisAPI api)
        {
            if (!api.MyNetwork.NetworkConnected)
            {
                api.Prompt("Cannot access App Market without an internet connection.", PyxisAPI.Product, PromptType.OKOnly);
                return;
            }
            
            API = api;
            if (API.desktop._mnu.count > 1) API.desktop._mnu.remove(1);

            if (!bLoaded)
            {
                MM = new ModalMessage("Loading App Market; Please Wait", api);
                new Thread(CreateApp).Start();
                MM.Start();
                bLoaded = true;
            }

            // Display App
            API.desktop._mnu.add(AppMenu);
            API.ActiveForm = frmMain;

        }

        public static void Quit()
        {
            if (!bLoaded) return;

            API.desktop.mnuRun.RemoveItem(mnuSwitchToApp);
            API.desktop.mnuForce.RemoveItem(mnuQuitApp);
            if (API.desktop.mnuForce.ItemCount == 0) API.desktop.mnuForce.Enabled = false;
            if (API.desktop.mnuRun.ItemCount == 0) API.desktop.mnuRun.Enabled = false;

            API.DisplayDesktop();

            ILB = null;
            frmMain = null;
            frmInfo.ClearChildren();
            frmInfo = null;
            mnuQuitApp = null;
            mnuSwitchToApp = null;

            bLoaded = false;
        }

        #endregion

        #region Private Methods

        private static void CreateApp()
        {
            Thread.Sleep(50);

            // Create List Form
            frmMain = new Form(API, Colors.White, true, true);

            ILB = new ImageListbox(0, 0, frmMain.Width, frmMain.Height);
            ILB.SelectedIndexChanged += new OnSelectedIndexChange(ILB_SelectedIndexChanged);
            frmMain.AddChild(ILB);

            // Create Info Form
            frmInfo = new Form(API, Colors.White, true, true);
            frmInfo.AutoScroll = true;

            // Create Application Menus
            AppMenu = new MenuItem("App Market");

            AppMenu.AddItem(new MenuItem("Search"));
            AppMenu.Item(0).tapEvent += new MenuItemTap((object sender) => startSearch());

            AppMenu.AddItem(new MenuItem("-"));

            AppMenu.AddItem(new MenuItem("Quit"));
            AppMenu.Item(2).tapEvent += new MenuItemTap((object sender) => Quit());

            // Create Switch/Quit Menus
            mnuSwitchToApp = new MenuItem("App Market");
            mnuSwitchToApp.tapEvent += new MenuItemTap((object sender) => Show(API));
            mnuSwitchToApp.Tag = "App Market";
            API.desktop.mnuRun.AddItem(mnuSwitchToApp);
            API.desktop.mnuRun.Enabled = true;

            mnuQuitApp = new MenuItem("App Market");
            mnuQuitApp.tapEvent += new MenuItemTap((object sender) => Quit());
            mnuQuitApp.Tag = "App Market";
            API.desktop.mnuForce.AddItem(mnuQuitApp);
            API.desktop.mnuForce.Enabled = true;

            // Load Apps
            _search = string.Empty;
            _searchThread = new Thread(Search);
            _searchThread.Priority = ThreadPriority.AboveNormal;
            _searchThread.Start();

            MM.Stop();
        }

        private static void ILB_SelectedIndexChanged(object sender, int index)
        {
            // Update Title & Form
            AppMenu.Text = "App Market [Loading]";
            frmInfo.ClearChildren();
            API.ActiveForm = frmInfo;

            // Download Information
            try
            {
                ImageListbox.App IA = ILB.SelectedItem;
                string[] items = new string(UTF8Encoding.UTF8.GetChars(API.MyNetwork.DownloadURL("http://www.skewworks.com/appstore/pyxis2/info.php?id=" + IA.ID))).Split('�');


                // Handle Bad Requests
                if (items[3] == string.Empty)
                {
                    // Null Item
                    frmInfo.AddChild(new RichTextLabel("<Font name='Arial'><b>App Not Found</b></font>", 4, 4));
                    CommandButton btnBack = new CommandButton("Back", 4, 40);
                    btnBack.tapEvent += new OnTap((object mysender, point e) => API.ActiveForm = frmMain);
                    frmInfo.AddChild(btnBack);
                    AppMenu.Text = "App Market";
                    return;
                }

                Label lblTitle = new Label(items[0], 48, 4);
                lblTitle.Font = FontManager.ArialBold;
                frmInfo.AddChild(lblTitle);

                Label lblDev = new Label(items[1], 48, 24);
                lblDev.Font = FontManager.ArialItalic;
                frmInfo.AddChild(lblDev);

                RichTextLabel lblDesc = new RichTextLabel(items[4], 4, 48, frmInfo.Width - 4, frmInfo.Height - 60);
                frmInfo.AddChild(lblDesc);

                if (items[2] == "0")
                {
                    CommandButton btnDL = new CommandButton("FREE Download", 4, 40);
                    btnDL.tapEvent += new OnTap((object mysender, point e) => DownloadApp(items[5]));
                    btnDL.Width = FontManager.ComputeExtentEx(FontManager.Arial, btnDL.Text).Width + 8;
                    btnDL.Y = frmInfo.Height - btnDL.Height - 4;
                    btnDL.X = 4;
                    frmInfo.AddChild(btnDL);

                    CommandButton btnBack2 = new CommandButton("Back", 4, 40);
                    btnBack2.tapEvent += new OnTap((object mysender, point e) => API.ActiveForm = frmMain);
                    btnBack2.Width = FontManager.ComputeExtentEx(FontManager.Arial, btnBack2.Text).Width + 8;
                    btnBack2.Y = frmInfo.Height - btnBack2.Height - 4;
                    btnBack2.X = frmInfo.Width - btnBack2.Width - 4;
                    frmInfo.AddChild(btnBack2);
                }
                else
                {
                    CommandButton btnBack2 = new CommandButton("Only Free Apps Can Be Downloaded In This Version", 4, 40);
                    btnBack2.tapEvent += new OnTap((object mysender, point e) => API.ActiveForm = frmMain);
                    btnBack2.Width = FontManager.ComputeExtentEx(FontManager.Arial, btnBack2.Text).Width + 8;
                    btnBack2.Y = frmInfo.Height - btnBack2.Height - 4;
                    btnBack2.X = frmInfo.Width / 2 - btnBack2.Width / 2;
                    frmInfo.AddChild(btnBack2);
                }

                Picturebox pbox = new Picturebox(PyxisAPI.ImageFromBytes(API.MyNetwork.DownloadURL(items[3])), 4, 4);
                pbox.BorderStyle = BorderStyle.BorderNone;
                frmInfo.AddChild(pbox);

                AppMenu.Text = "App Market";
            }
            catch (Exception)
            {
                AppMenu.Text = "App Market";
                API.ActiveForm = frmMain;
                API.Prompt("Could not get application details!", PyxisAPI.Product, PromptType.OKOnly);
            }
        }

        private static void startSearch()
        {
            string sRes = API.Inputbox("What would you like to search for?", "App Market");
            if (sRes == string.Empty)
                return;
            _search = sRes;
            Search();
        }

        private static void Search()
        {
            ImageListbox.App IA;
            string[] Entries;
            string[] Items;

            // Update Title & List
            AppMenu.Text = "App Market [Loading]";
            ILB.Clear();

            // Download Info
            try
            {
                string sData = new string(UTF8Encoding.UTF8.GetChars(API.MyNetwork.DownloadURL("http://www.skewworks.com/appstore/pyxis2/?search=" + _search)));

                // Check for null data
                if (sData == string.Empty)
                {
                    AppMenu.Text = "App Market [Empty]";
                    return;
                }

                // Parse Data
                Entries = sData.Split('�');
                for (int i = 0; i < Entries.Length - 1; i++)
                {
                    IA = new ImageListbox.App();
                    Items = Entries[i].Split('�');
                    IA.ID = Items[0];
                    IA.Title = Items[1];
                    IA.Developer = Items[2];
                    IA.Price = (Items[3] == "0") ? "FREE" : "$" + Items[3];
                    IA.ImgURL = Items[4];
                    ILB.AddItem(IA);
                }
            }
            catch (Exception)
            {
                API.Prompt("Could not contact App Market", PyxisAPI.Product, PromptType.OKOnly);
            }

            // Update Title
            AppMenu.Text = "App Market";
        }

        private static void ShowMessage(string Message, Picturebox pbox)
        {
            Bitmap bmp = new Bitmap(pbox.Width, pbox.Height);
            bmp.DrawRectangle(Colors.Black, 0, 0, 0, pbox.Width, pbox.Height, 0, 0, Colors.Black, 0, 0, Colors.Black, 0, 0, 256);
            bmp.DrawTextInRect(Message, 4, 4, pbox.Width - 8, pbox.Height - 8, Bitmap.DT_AlignmentLeft, Colors.White, FontManager.Arial);
            pbox.Image = bmp;
        }

        private static void DownloadApp(string url)
        {
            // Prep Window
            int y = (AppearanceManager.ScreenHeight / 2) - 26;
            Form frmDownload = new Form(API, Colors.LightGray, 10, y, AppearanceManager.ScreenWidth - 20, 51, true, true, Form.WindowType.container);
            Label lblStatus = new Label("Preparing to download...", 8, 8);
            Progressbar progDownload = new Progressbar(8, 28, frmDownload.Width - 16, 15);
            frmDownload.AddChild(lblStatus);
            frmDownload.AddChild(progDownload);

            API.ScreenBuffer.DrawRectangle(Color.Black, 0, 0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight, 0, 0, Colors.Black, 0, 0, Colors.Black, 0, 0, 100);
            API.ScreenBuffer.Flush();
            API.ActiveForm = frmDownload;

            try
            {
                // Download File
                progDownload.Value = 0;
                lblStatus.Text = "Downloading Application...";
                string sName = API.MyDrives.RootDirectory + "\\documents\\temp\\" + url.Substring(url.LastIndexOf("/") + 1);
                API.MyNetwork.DownloadFile(url, sName, progDownload);

                // Install File
                lblStatus.Text = "Installing Application...";
                if (File.Exists(sName))
                {
                    API.InstallApplication(sName);
                    File.Delete(sName);
                }

            }
            catch (Exception) { }

            frmInfo.ClearChildren();
            API.ActiveForm = frmMain;
            API.desktop.Render(true);
        }

        #endregion

        #region Custom Control

        private class ImageListbox : Control
        {

            #region Structure

            public struct App
            {
                public string ID;
                public string Title;
                public string Developer;
                public string ImgURL;
                public Bitmap Image;
                public string Price;
            }

            #endregion

            #region Variables

            private Color _bkg = Colors.LightGray;
            private ArrayList _items = new ArrayList();
            private int _selIndex = -1;
            private int _scrollY = 0;
            private int _mY = 0;
            private bool _bMoved = false;
            private Thread _imgLoader;

            #endregion

            #region Contructors

            public ImageListbox(int x, int y, int width, int height)
            {
                _x = x;
                _y = y;
                _w = width;
                _h = height;
                _imgLoader = new Thread(LoadImages);
                _imgLoader.Priority = ThreadPriority.AboveNormal;
            }

            public ImageListbox(int x, int y, int width, int height, string[] items)
            {
                _x = x;
                _y = y;
                _w = width;
                _h = height;
                for (int i = 0; i < items.Length; i++)
                {
                    _items.Add(items[i]);
                }
                if (items != null) _selIndex = 0;
                _imgLoader = new Thread(LoadImages);
                _imgLoader.Priority = ThreadPriority.AboveNormal;
            }

            #endregion

            #region Touch Invokes

            public override void TouchDown(object sender, point e)
            {
                _mY = e.Y;
                _mDown = true;
            }

            public override void TouchUp(object sender, point e)
            {
                if (_mDown)
                {
                    if (_bMoved)
                    {
                        _bMoved = false;
                    }
                    else
                    {
                        if (this.ScreenBounds.contains(e))
                        {
                            int y = e.Y - Top + -(_scrollY);
                            int index = 0;
                            while (y > 48)
                            {
                                y -= 48;
                                index++;
                            }
                            if (index <= _items.Count)
                            {
                                SelectedIndex = index;
                            }

                            OnTap(this, new point(e.X - Left, e.Y - Top));
                        }
                    }
                    _mDown = false;
                }
            }

            public override void TouchMove(object sender, point e)
            {
                int nScroll = _scrollY + (e.Y - _mY);
                if (nScroll > 0) nScroll = 0;
                if (nScroll < -(_items.Count * 48) + _h - 2) nScroll = -(_items.Count * 48) + _h - 2;
                _mY = e.Y;
                _bMoved = true;
                if (_scrollY != nScroll)
                {
                    _scrollY = nScroll;
                    Render(true);
                }
            }

            #endregion

            #region  Properties

            public int SelectedIndex
            {
                get { return _selIndex; }
                set
                {
                    _selIndex = value;
                    OnSelectedIndexChange(this, value);
                }
            }

            public App SelectedItem
            {
                get { return (App)_items[_selIndex]; }
            }

            public override int Height
            {
                get { return _h; }
                set
                {
                    if (value < 30) value = 30;
                    _h = value;
                    if (_parent != null) _parent.Render();
                }
            }

            #endregion

            #region Events

            public event OnSelectedIndexChange SelectedIndexChanged;

            /// <summary>
            /// Event for Taps
            /// </summary>
            /// <param name="sender"></param>
            protected virtual void OnSelectedIndexChange(Object sender, int e)
            {
                if (SelectedIndexChanged != null) SelectedIndexChanged(sender, e);
            }

            #endregion

            #region Public Methods

            public void AddItem(App Application)
            {
                _items.Add(Application);
                if (_selIndex < 0) _selIndex = 0;
                Render(true);

                if (!_imgLoader.IsAlive)
                {
                    _imgLoader = new Thread(LoadImages);
                    _imgLoader.Start();
                }
            }

            public void Clear()
            {
                _items.Clear();
                Render(true);
            }

            public void RemoveItem(App Application)
            {
                _items.Remove(Application);
                if (_selIndex > _items.Count) _selIndex = _items.Count;
                Render(true);
            }

            public void RemoveItemAt(int index)
            {
                _items.RemoveAt(index);
                if (_selIndex > _items.Count) _selIndex = _items.Count;
                Render(true);
            }

            #endregion

            #region GUI

            public override void Render(bool flush)
            {
                if (!_visible || _parent == null || _parent.ScreenBuffer == null || _suspend) return;

                // Set clipping region in case we're off parent somewhere (can happen w/ scroll)
                _parent.ScreenBuffer.SetClippingRectangle(_parent.Left, _parent.Top, _parent.Width, _parent.Height);

                int totalH = _items.Count * 48;
                int wOffset = 0;
                int y = _scrollY + Top + 1;
                bool bScroll = false;
                App IA;

                rect Region = rect.intersect(new rect(_parent.Left, _parent.Top, _parent.Width, _parent.Height), new rect(Left + 1, Top + 1, _w - 2, _h - 2));
                _parent.ScreenBuffer.SetClippingRectangle(Region.X, Region.Y, Region.Width, Region.Height);
                _parent.ScreenBuffer.DrawRectangle(Color.Black, 0, Left, Top, _w, _h, 0, 0, _bkg, 0, 0, _bkg, 0, 0, 256);

                if (totalH > _h)
                {
                    wOffset = 8;
                    bScroll = true;
                }

                for (int i = 0; i < _items.Count; i++)
                {
                    _parent.ScreenBuffer.DrawRectangle(Color.White, 1, Left + 1, y, _w - 2, 48, 0, 0, Color.White, 0, 0, Color.White, 0, 0, 256);

                    if (i < _items.Count - 1) _parent.ScreenBuffer.DrawLine(Colors.LightGray, 1, _x + 5, y + 47, _x + _w - 10 - wOffset, y + 47);

                    IA = (App)_items[i];
                    if (IA.Image != null)
                        _parent.ScreenBuffer.DrawImage(_x + 5, y + 5, IA.Image, 0, 0, 32, 32);
                    _parent.ScreenBuffer.DrawTextInRect(IA.Title, _x + 42, y + 5, _w - (FontManager.ComputeExtentEx(FontManager.ArialBold,IA.Price) .Width) - 4 - wOffset, 20, Bitmap.DT_AlignmentLeft + Bitmap.DT_TrimmingCharacterEllipsis, Color.Black, FontManager.Arial);
                    _parent.ScreenBuffer.DrawTextInRect(IA.Developer, _x + 42, y + 20, _w - wOffset, 20, Bitmap.DT_AlignmentLeft + Bitmap.DT_TrimmingCharacterEllipsis, Colors.Gray, FontManager.ArialItalic);
                    _parent.ScreenBuffer.DrawText(IA.Price, FontManager.ArialBold, Color.Black, _x + _w - wOffset - (FontManager.ComputeExtentEx(FontManager.ArialBold, IA.Price).Width) - 4, y + 5);

                    y += 48;
                }

                if (bScroll)
                {
                    _parent.ScreenBuffer.DrawRectangle(Colors.DarkGray, 1, Left + _w - 9, Top + 1, 9, _h - 2, 0, 0, Colors.DarkGray, 0, 0, Colors.DarkGray, 0, 0, 256);

                    float sH = (float)(totalH - _h);
                    float sY = (sH == 0) ? 0 : -((float)_scrollY) / (float)(totalH - _h);
                    int iSY = (int)((float)(_h - 32) * sY);
                    _parent.ScreenBuffer.DrawRectangle(Colors.LightGray, 1, Left + _w - 9, Top + 1 + iSY, 9, 20, 0, 0, Colors.LightGray, 0, 0, Colors.LightGray, 0, 0, 256);
                }

                if (flush)
                {
                    _parent.ScreenBuffer.Flush(Left, Top, _w, _h);
                    _parent.ScreenBuffer.SetClippingRectangle(0, 0, AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
                }
            }

            private void LoadImages()
            {
                App IA;

                for (int i = 0; i < _items.Count; i++)
                {
                    IA = (App)_items[i];
                    if (IA.Image == null)
                    {
                        IA.Image = PyxisAPI.ImageFromBytes(API.MyNetwork.DownloadURL(IA.ImgURL));
                        _items[i] = IA;
                        Render(true);
                    }
                }
            }

            #endregion

        }

        #endregion

    }


}
