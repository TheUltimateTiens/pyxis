using System;
using System.Threading;

using Microsoft.SPOT;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.GUI.Controls;

namespace Skewworks.Pyxis.Kernel
{
    public class MenuTrayIcon
    {

        #region Variables

        private ApplicationKey _appkey;
        private Image32 _icon;

        protected internal MenuTray _parent;
        protected internal rect _bounds;

        protected internal bool _mDown = false;         // True when Pen Down
        protected internal TapState _eTapHold;          // TapHold used to wait for ContextMenus
        protected internal point _ptTapHold;

        #endregion

        #region Constructor

        public MenuTrayIcon(ApplicationKey AppKey, Image32 Icon)
        {
            if (AppKey == null && AppDomain.CurrentDomain.FriendlyName != "default")
                throw new Exception("Application Key is required!");

            if (Icon == null)
                throw new Exception("Cannot have a null icon");

            if (Icon.Width != 16 || Icon.Height != 16)
                throw new Exception("Invalid icon size");

            _appkey = AppKey;
            _icon = Icon;

        }

        #endregion

        #region Properties

        public ApplicationKey ApplicationKey
        {
            get { return _appkey; }
        }

        public Image32 Icon
        {
            get { return _icon; }
            set
            {
                if (value == null)
                    throw new Exception("Cannot have a null icon");

                if (value.Width != 16 || value.Height != 16)
                    throw new Exception("Invalid icon size");

                _icon = value;
                _parent.Render(true);
            }
        }

        #endregion

        #region Events

        public event OnTap tapEvent;

        /// <summary>
        /// Event for Taps
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTap(object sender, point e)
        {
            if (tapEvent != null)
                tapEvent(sender, e);
        }

        public event OnTapHold TapHold;

        /// <summary>
        /// Event for Tap & Hold
        /// </summary>
        /// <param name="sender"></param>
        protected virtual void OnTapHold(object sender, point e)
        {
            if (TapHold != null) TapHold(sender, e);
        }

        #endregion

        #region Touch Methods

        public void TouchDown(object sender, point e)
        {
            _mDown = true;

            // Begin TapHold
            _ptTapHold = e;
            _eTapHold = TapState.THWaiting;
            Thread thHold = new Thread(TapHoldWaiter);
            thHold.Start();

        }

        public virtual void TouchUp(object sender, point e)
        {

            // Check Tap Hold
            if (_eTapHold == TapState.THComplete)
            {
                _eTapHold = TapState.Normal;
                return;
            }
            _eTapHold = TapState.Normal;

            // Perform normal tap
            if (_mDown)
            {
                if (_bounds.contains(e)) OnTap(this, new point(e.X, e.Y));
                _mDown = false;
            }
        }

        private void TapHoldWaiter()
        {
            Thread.Sleep(750);
            if (_eTapHold == TapState.Normal)
                return;

            OnTapHold(this, _ptTapHold);
        }

        #endregion

    }
}
