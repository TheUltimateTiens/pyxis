/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.Collections;

using Microsoft.SPOT;
using Microsoft.SPOT.IO;

using GHIElectronics.NETMF.IO;
using GHIElectronics.NETMF.USBHost;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.GUI.Controls;

namespace Skewworks.Pyxis.Kernel
{

    internal struct PyxisApplication
    {
        public AppDomain Domain;
        public ApplicationKey Key;
        public AppStartup StartupInfo;
        public ArrayList Forms;
    }

    [Serializable]
    public struct PyxisService
    {
        public ServiceKey Key;
        public ServiceInfo Info;
        public PyxisService(ServiceKey Key, ServiceInfo Info)
        {
            this.Key = Key;
            this.Info = Info;
        }
    }

    /// <summary>
    /// Application Startup Details
    /// </summary>
    [Serializable]
    public struct AppStartup
    {
        public string title;
        public string company;
        public string copyright;
        public string description;
        public Form startupForm;
        public MenuItem[] menus;
    }

    /// <summary>
    /// Application Icon Details
    /// </summary>
    [Serializable]
    public struct AppIcon
    {
        public string title;
        public byte[] icon;
        public AppIcon(string title, byte[] icon)
        {
            try
            {
                Bitmap bmp = PyxisAPI.ImageFromBytes(icon);
                if (bmp.Width != 32 || bmp.Height != 32) throw new Exception("Invalid icon size; must be 32x32");
            }
            catch (Exception)
            {
                throw new Exception("Invalid icon Format");
            }
            this.title = title;
            this.icon = icon;
        }
        private Bitmap GetBitmap(byte[] data)
        {
            return PyxisAPI.ImageFromBytes(icon);
        }
    }

    internal struct TouchEventArgs
    {
        public point location;
        public int type;
        public TouchEventArgs(point e, int type)
        {
            this.location = e;
            this.type = type;
        }
    }

}
