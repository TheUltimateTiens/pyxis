﻿/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Presentation.Media;

namespace Skewworks.Pyxis.Kernel
{
    public static class Colors
    {

        public static readonly Color Black = ColorUtility.ColorFromRGB(0, 0, 0);
        public static readonly Color Blue = ColorUtility.ColorFromRGB(0, 0, 255);
        public static readonly Color Brown = ColorUtility.ColorFromRGB(165, 42, 42);
        public static readonly Color Cyan = ColorUtility.ColorFromRGB(0, 255, 255);
        public static readonly Color DarkGray = ColorUtility.ColorFromRGB(169, 169, 169);
        public static readonly Color Gray = ColorUtility.ColorFromRGB(128, 128, 128);
        public static readonly Color Green = ColorUtility.ColorFromRGB(0, 128, 0);
        public static readonly Color LightGray = ColorUtility.ColorFromRGB(211, 211, 211);
        public static readonly Color Magenta = ColorUtility.ColorFromRGB(255, 0, 255);
        public static readonly Color Orange = ColorUtility.ColorFromRGB(255, 165, 0);
        public static readonly Color Purple = ColorUtility.ColorFromRGB(128, 0, 128);
        public static readonly Color Red = ColorUtility.ColorFromRGB(255, 0, 0);
        public static readonly Color Wheat = ColorUtility.ColorFromRGB(237, 237, 237);
        public static readonly Color White = ColorUtility.ColorFromRGB(255, 255, 255);
        public static readonly Color Yellow = ColorUtility.ColorFromRGB(255, 255, 0);

        public static Color FromString(string ColVal)
        {
            string[] vals = ColVal.Split(',');
            return ColorUtility.ColorFromRGB(byte.Parse(vals[0]), byte.Parse(vals[1]), byte.Parse(vals[2]));
        }

    }
}
