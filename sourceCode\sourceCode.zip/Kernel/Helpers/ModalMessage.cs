using System;
using System.Threading;

using Microsoft.SPOT;

using Skewworks.Pyxis.EXT;
using Skewworks.Pyxis.GUI.Controls;

namespace Skewworks.Pyxis.Kernel
{
    public class ModalMessage
    {

        #region Variables

        private Bitmap _bmp;
        private string _msg;
        private ManualResetEvent _evnt;
        private PyxisAPI API;
        private bool _bContinue;

        #endregion

        #region Constructor

        public ModalMessage(string Message, PyxisAPI api)
        {
            _msg = Message;
            API = api;
        }

        #endregion

        #region Properties

        public string Message
        {
            get { return _msg; }
            set { _msg = value; }
        }

        #endregion

        #region Public Methods

        public void Start(bool Blocking = true)
        {
            int w, h, x, y, i;

            // Create the reset event
            _bContinue = true;
            _evnt = new ManualResetEvent(false);

            // Update API Modal state
            API.SetModalState(true);

            // Copy out the current buffer
            _bmp = new Bitmap(AppearanceManager.ScreenWidth, AppearanceManager.ScreenHeight);
            _bmp.DrawImage(0, 0, API._buffer, 0, 0, _bmp.Width, _bmp.Height);

            // First figure out how wide to make the window
            FontManager.Arial.ComputeExtent(PyxisAPI.Product, out w, out h);
            size sz = FontManager.ComputeExtentEx(FontManager.Arial, _msg);
            if (sz.Width > w) w = sz.Width;

            // Add border
            w += 16;

            // Check Mimimum Width
            if (w < 76) w = 76;

            // Now make sure we're within the screen width
            if (w > AppearanceManager.ScreenWidth - 8) w = AppearanceManager.ScreenWidth - 8;

            // Get the height of the 2 strings combined
            // We already have the title height in h
            // Remove 16px for 2 borders + 2 spacers (4+4+4+4)
            FontManager.Arial.ComputeTextInRect(_msg, out y, out i, w - 16);
            h = h + i;

            // Add borders and spacing 49px (4 border + 2 space + title + 2 space + 4 border = 4 space + text height + 4 space + CommandButton height + 4 space + 4 border)
            h = h + 20;

            // Make sure we're still on the screen
            if (h > AppearanceManager.ScreenHeight - 8) h = AppearanceManager.ScreenHeight - 8;

            // Center the window
            x = (int)(((float)AppearanceManager.ScreenWidth / 2) - ((float)w / 2));
            y = (int)(((float)AppearanceManager.ScreenHeight / 2) - ((float)h / 2));

            if (!_bContinue)
                return;

            // We're ready to create the window
            Form frmLaunch = new Form(API, Colors.LightGray, x, y, w, h, true, true, Form.WindowType.fullborder);
            frmLaunch.AddChild(new Label(PyxisAPI.Product, Colors.White, 6, 5, w - 10, FontManager.Arial.Height));
            frmLaunch.AddChild(new Label(_msg, Colors.Black, 8, 5 + FontManager.Arial.Height + 6, w - 16, h - 20 - FontManager.Arial.Height));

            if (!_bContinue)
                return;
            
            // Set the Active Form (without rendering)
            API._ActiveForm = frmLaunch;

            if (!_bContinue)
                return;

            // Draw Prompt
            API._buffer.DrawRectangle(Colors.Black, 0, 0, 0, _bmp.Width, _bmp.Height, 0, 0, Colors.Black, 0, 0, Colors.Black, 0, 0, 100);
            API._buffer.Flush();
            frmLaunch.Render();

            if (!_bContinue)
                return;

            // Lock the thread
            if (Blocking)
            {
                _evnt.Reset();
                while (!_evnt.WaitOne(1000, false))
                {
                    ;
                }
            }

        }

        public void Stop()
        {
            _bContinue = false;
            API.SetModalState(false);
            if (_bmp != null)
            {
                API.ScreenBuffer.SetClippingRectangle(0, 0, _bmp.Width, _bmp.Height);
                API.ScreenBuffer.DrawImage(0, 0, _bmp, 0, 0, _bmp.Width, _bmp.Height);
                API.ScreenBuffer.Flush();
            }
            if (_evnt != null)
                _evnt.Set();
            _bmp = null;
            _evnt = null;
        }

        #endregion

    }
}
