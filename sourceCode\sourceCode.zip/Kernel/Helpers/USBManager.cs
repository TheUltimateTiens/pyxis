/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

using GHIElectronics.NETMF.IO;
using GHIElectronics.NETMF.USBHost;

namespace Skewworks.Pyxis.Kernel
{
    public class USBManager : MarshalByRefObject
    {

        #region Variables

        PyxisAPI API;

        #endregion

        #region Constructor

        public USBManager(PyxisAPI api)
        {

            API = api;

            if (SystemInfo.SystemID.SKU == 3) return;

            // Subscribe to USBH events.
            USBHostController.DeviceConnectedEvent += DeviceConnectedEvent;
            USBHostController.DeviceDisconnectedEvent += DeviceDisconnectedEvent;
        }

        #endregion

        #region Private Methods

        private void DeviceConnectedEvent(USBH_Device device)
        {
            switch (device.TYPE)
            {
                case USBH_DeviceType.MassStorage:
                    API.MyDrives.AddUSBDrive(device);
                    break;
                default:
                    Debug.Print("USB type not yet implemented.");
                    break;
            }
        }

        private void DeviceDisconnectedEvent(USBH_Device device)
        {
            switch (device.TYPE)
            {
                case USBH_DeviceType.MassStorage:
                    // No nothing
                    // The DriveManager will detect the FileSystem Unmounting
                    break;
                default:
                    // Do nothing
                    break;
            }
        }

        #endregion

    }
}
