/*
Copyright 2010 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.Kernel
{

    public enum ScreenCalibration
    {
        None = 0,
        Gather = 1,
        Restore = 2,
    }

    public enum ScaleMode
    {
        Normal = 0,
        Stretch = 1,
        Scale = 2,
    }

    public enum BorderStyle
    {
        Border3D = 0,
        BorderFlat = 1,
        BorderNone = 2
    }

    public enum PressedState
    {
        Normal = 0,
        Pressed = 1,
    }

    public enum PromptType
    {
        OKOnly = 0,
        OKCancel = 1,
        YesNo = 2,
        YesNoCancel = 3,
    }

    public enum PromptResult
    {
        OK = 0,
        Cancel = 1,
        Yes = 2,
        No = 3,
    }

    public enum Orientation
    {
        Horizontal = 0,
        Vertical = 1,
    }

    public enum NetworkConnectionType
    {
        None = 0,
        DHCP = 1,
        StaticIP = 2,
    }

}
