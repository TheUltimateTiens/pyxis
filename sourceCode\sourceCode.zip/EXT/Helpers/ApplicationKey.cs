/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.EXT
{

    public interface IApplicationKey
    {

        int ApplicationID
        {
            get;
        }

        string ApplicationDirectory
        {
            get;
        }

        AppDomain ApplicationDomain
        {
            get;
        }

    }

    public class ApplicationKey : MarshalByRefObject, IApplicationKey
    {

        #region Variables

        private int _AppID;
        private AppDomain _AppDomain;
        private string _path;

        #endregion

        #region Constructor

        public ApplicationKey(int AppID, AppDomain AppDomain, string ApplicationPath)
        {
            if (AppDomain.CurrentDomain.FriendlyName != "default")
                throw new Exception(Resources.GetString(Resources.StringResources.DefaultDomainError));

            _AppDomain = AppDomain;
            _AppID = AppID;
            _path = ApplicationPath;
        }

        #endregion

        #region Properties

        public int ApplicationID
        {
            get { return _AppID; }
        }

        public string ApplicationDirectory
        {
            get { return _path; }
        }

        public AppDomain ApplicationDomain
        {
            get { return _AppDomain; }
        }

        #endregion

    }

    public interface IServiceKey
    {
        int ServiceID
        {
            get;
        }

        string ServicePath
        {
            get;
        }

        AppDomain AppDomain
        {
            get;
        }
    }

    public class ServiceKey : MarshalByRefObject, IServiceKey
    {

        #region Variables

        private int _AppID;
        private AppDomain _AppDomain;
        private string _path;

        #endregion

        #region Constructor

        public ServiceKey(int AppID, AppDomain AppDomain, string ServicePath)
        {
            if (AppDomain.CurrentDomain.FriendlyName != "default")
                throw new Exception(Resources.GetString(Resources.StringResources.DefaultDomainError));

            _AppDomain = AppDomain;
            _AppID = AppID;
            _path = ServicePath;
        }

        #endregion

        #region Properties

        public int ServiceID
        {
            get { return _AppID; }
        }

        public string ServicePath
        {
            get { return _path; }
        }

        public AppDomain AppDomain
        {
            get { return _AppDomain; }
        }

        #endregion

    }

}
