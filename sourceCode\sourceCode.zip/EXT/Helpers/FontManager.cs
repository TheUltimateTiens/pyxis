/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.EXT
{
    public static class FontManager
    {

        #region Variables

        public static Font Arial = Resources.GetFont(Resources.FontResources.arial);
        public static Font ArialBold = Resources.GetFont(Resources.FontResources.arial_bold);
        public static Font ArialBoldItalic = Resources.GetFont(Resources.FontResources.arial_bolditalic);
        public static Font ArialItalic = Resources.GetFont(Resources.FontResources.arial_italic);

        public static Font Gothic = Resources.GetFont(Resources.FontResources.gothic);
        public static Font GothicBold = Resources.GetFont(Resources.FontResources.gothic_bold);
        public static Font GothicBoldItalic = Resources.GetFont(Resources.FontResources.gothic_bolditalic);
        public static Font GothicItalic = Resources.GetFont(Resources.FontResources.gothic_italic);

        public static Font TimesRoman = Resources.GetFont(Resources.FontResources.timesroman);
        public static Font TimesRomanBold = Resources.GetFont(Resources.FontResources.timesroman_bold);
        public static Font TimesRomanBoldItalic = Resources.GetFont(Resources.FontResources.timesroman_bolditalic);
        public static Font TimesRomanItalic = Resources.GetFont(Resources.FontResources.timesroman_italic);

        #endregion

        #region Public Methods

        /// <summary>
        /// Overload for Font.ComputeExtent
        /// </summary>
        /// <param name="font">Font to use</param>
        /// <param name="value">Value to compute extent for</param>
        /// <returns></returns>
        public static size ComputeExtentEx(Font font, String value)
        {
            int w = 0;
            int h = 0;
            size sz = new size();

            string[] lines = value.Split('\n');

            for (int i = 0; i < lines.Length; i++)
            {
                font.ComputeExtent(lines[i], out w, out h);
                if (w > sz.Width) sz.Width = w;
            }

            sz.Height = font.Height * lines.Length;
            
            return sz;
        }

        #endregion

    }
}
