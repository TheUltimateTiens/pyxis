/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

using GHIElectronics.NETMF.Hardware;

namespace Skewworks.Pyxis.EXT
{
    public static class AppearanceManager
    {

        #region Variables

        public static readonly int ScreenWidth;
        public static readonly int ScreenHeight;

        #endregion

        #region Constructor

        static AppearanceManager()
        {
            int bitsPerPixel, orientationDeg;

            // Get the screen dimensions
            HardwareProvider.HwProvider.GetLCDMetrics(out ScreenWidth, out ScreenHeight, out bitsPerPixel, out orientationDeg);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Sets the Boot Logo to the default Skewworks logo
        /// </summary>
        /// <returns></returns>
        public static bool SetBootLogo()
        {
            // Only allow default domain to set the boot logo
            if (AppDomain.CurrentDomain.FriendlyName != "default") return false;

            // Don't set logo in emulator
            if (SystemInfo.SystemID.SKU == 3) return false;

            // Set the default boot logo
            Bitmap bmp = Resources.GetBitmap(Resources.BitmapResources.boot180);
            Configuration.StartUpLogo.Set(bmp.GetBitmap(), (int)(((float)ScreenWidth / 2) - 90), (int)(((float)ScreenHeight / 2) - 90));
            Configuration.StartUpLogo.Enabled = true;
            Configuration.LCD.EnableLCDBootupMessages(false);

            return true;
        }

        /// <summary>
        /// Sets the boot logo to the provided image and location
        /// 180x180 MAX
        /// </summary>
        /// <param name="Logo">Image to use</param>
        /// <param name="X">X location of image</param>
        /// <param name="Y">Y Location of image</param>
        /// <returns></returns>
        public static bool SetBootLogo(Bitmap Logo, int X, int Y)
        {
            // Only allow default domain to set the boot logo
            if (AppDomain.CurrentDomain.FriendlyName != "default") return false;

            // Don't set logo in emulator
            if (SystemInfo.SystemID.SKU == 3) return false;

            // Set the default boot logo
            Bitmap bmp = Resources.GetBitmap(Resources.BitmapResources.boot180);
            Configuration.StartUpLogo.Set(Logo.GetBitmap(), X, Y);
            Configuration.StartUpLogo.Enabled = true;
            Configuration.LCD.EnableLCDBootupMessages(false);

            return true;
        }

        #endregion

    }
}
