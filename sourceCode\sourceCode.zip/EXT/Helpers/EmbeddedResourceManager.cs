using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.EXT
{
    public class EmbeddedResourceManager
    {

        public static byte[] GetWallpaperByName(string Name)
        {
            switch (Name)
            {
                case "bluestripes":
                    return Resources.GetBytes(Resources.BinaryResources.bluestripes);
                case "greenstripes":
                    return Resources.GetBytes(Resources.BinaryResources.greenstripes);
                case "grunge":
                    return Resources.GetBytes(Resources.BinaryResources.grunge);
                case "pyxis2gray":
                    return Resources.GetBytes(Resources.BinaryResources.pyxis2_gray);
                default:
                    return null;
            }
        }

        public static Bitmap GetBitmapByName(string Name)
        {
            switch (Name)
            {
                case "colors":
                    return Resources.GetBitmap(Resources.BitmapResources.color_selection);
                default:
                    return null;
            }
        }

        public static byte[] GetImage32BytesByName(string Name)
        {
            switch (Name)
            {
                case "Application":
                    return (Resources.GetBytes(Resources.BinaryResources.Application));
                case "AppStore":
                    return (Resources.GetBytes(Resources.BinaryResources.App_Store));
                case "FileFinder":
                    return (Resources.GetBytes(Resources.BinaryResources.filefinder));
                case "PictureViewer":
                    return (Resources.GetBytes(Resources.BinaryResources.Picture_Viewer));
                case "Settings":
                    return (Resources.GetBytes(Resources.BinaryResources.settings));
                default:
                    return null;
            }
        }

    }
}
