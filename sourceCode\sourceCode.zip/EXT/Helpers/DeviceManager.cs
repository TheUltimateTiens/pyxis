using System;

using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace Skewworks.Pyxis.EXT
{
    public static class DeviceManager
    {

        public static DeviceType ActiveDevice
        {
            get
            {
                // Determine Device
                if (SystemInfo.SystemID.SKU == 3)
                {
                    return DeviceType.Emulator;
                }
                else
                {
                    switch (SystemInfo.SystemID.Model)
                    {
                        case 5:
                            return DeviceType.Cobra;
                        case 6:
                            return DeviceType.ChipworkX;
                        default:
                            return DeviceType.Unknown;
                    }
                }
            }
        }
        

    }
}
