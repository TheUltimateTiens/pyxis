/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using System.IO;

using Microsoft.SPOT;
using Microsoft.SPOT.IO;

using GHIElectronics.NETMF.IO;
using GHIElectronics.NETMF.USBHost;

namespace Skewworks.Pyxis
{

    /// <summary>
    /// Object Size
    /// </summary>
    [Serializable]
    public struct size
    {
        public int Width;
        public int Height;
        public size(int Width, int Height)
        {
            this.Width = Width;
            this.Height = Height;
        }
    }

    /// <summary>
    /// SD or USB Hard Drive
    /// </summary>
    [Serializable]
    public struct PyxisDrive
    {
        public PersistentStorage ps;
        public bool Formatted;
        public string VolumeName;
        public string RootName;
        public USBH_Device Device;
        public VolumeInfo VolumeInfo;
    }

    /// <summary>
    /// Point coordinates
    /// </summary>
    [Serializable]
    public struct point
    {
        public int X;
        public int Y;
        public point(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }


    /// <summary>
    /// Rectangle (Rect) Structure
    /// </summary>
    [Serializable]
    public struct rect
    {
        public int X;
        public int Y;
        public int Width;
        public int Height;
        public rect(int X, int Y, int Width, int Height)
        {
            this.X = X;
            this.Y = Y;
            this.Width = Width;
            this.Height = Height;
        }
        public bool contains(int x, int y)
        {
            if (x >= this.X && x <= this.X + this.Width && y >= this.Y && y <= this.Y + this.Height) return true;
            return false;
        }
        public bool contains(point e)
        {
            if (e.X >= this.X && e.X <= this.X + this.Width && e.Y >= this.Y && e.Y <= this.Y + this.Height) return true;
            return false;
        }
        public bool intersects(rect area)
        {
            return !(area.X >= (this.X + this.Width)
                    || (area.X + area.Width) <= this.X
                    || area.Y >= (this.Y + this.Height)
                    || (area.Y + area.Height) <= this.Y
                    );
        }
        public void combine(rect newRect)
        {
            if (this.Width == 0)
            {
                this.X = newRect.X;
                this.Y = newRect.Y;
                this.Width = newRect.Width;
                this.Height = newRect.Height;
                return;
            }

            int x1, y1, x2, y2;
            x1 = (this.X < newRect.X) ? this.X : newRect.X;
            y1 = (this.Y < newRect.Y) ? this.Y : newRect.Y;
            x2 = (this.X + this.Width > newRect.X + newRect.Width) ? this.X + this.Width : newRect.X + newRect.Width;
            y2 = (this.Y + this.Height > newRect.Y + newRect.Height) ? this.Y + this.Height : newRect.Y + newRect.Height;
            this.X = x1;
            this.Y = y1;
            this.Width = x2 - x1;
            this.Height = y2 - y1;
        }
        public rect combine(rect region1, rect region2)
        {
            if (region1.Width == 0) return region2;
            if (region2.Width == 0) return region1;

            int x1, y1, x2, y2;
            x1 = (region1.X < region2.X) ? region1.X : region2.X;
            y1 = (region1.Y < region2.Y) ? region1.Y : region2.Y;
            x2 = (region1.X + region1.Width > region2.X + region2.Width) ? region1.X + region1.Width : region2.X + region2.Width;
            y2 = (region1.Y + region1.Height > region2.Y + region2.Height) ? region1.Y + region1.Height : region2.Y + region2.Height;
            return new rect(x1, y1, x2 - x1, y2 - y1);
        }
        public static rect intersect(rect region1, rect region2)
        {
            if (!region1.intersects(region2)) return new rect(0, 0, 0, 0);

            rect rct = new rect();

            // For X1 & Y1 we'll want the highest value
            rct.X = (region1.X > region2.X) ? region1.X : region2.X;
            rct.Y = (region1.Y > region2.Y) ? region1.Y : region2.Y;

            // For X2 & Y2 we'll want the lowest value
            int r1V2 = region1.X + region1.Width;
            int r2V2 = region2.X + region2.Width;
            rct.Width = (r1V2 < r2V2) ? r1V2 - rct.X : r2V2 - rct.X;
            r1V2 = region1.Y + region1.Height;
            r2V2 = region2.Y + region2.Height;
            rct.Height = (r1V2 < r2V2) ? r1V2 - rct.Y : r2V2 - rct.Y;

            return rct;
        }
    }

    [Serializable]
    public struct ServiceInfo
    {
        public string Name;
        public string Location;
        public StartMode StartMode;
        public bool IsRunning;
        public bool HasGUI;
        public ServiceInfo(string Name, string Location, StartMode StartMode, bool IsRunning, bool HasGUI)
        {
            this.Name = Name;
            this.Location = Location;
            this.StartMode = StartMode;
            this.IsRunning = IsRunning;
            this.HasGUI = HasGUI;
        }
        public ServiceInfo(string Name, string Location)
        {
            this.Name = Name;
            this.Location = Location;
            this.StartMode = Pyxis.StartMode.Manual;
            this.IsRunning = false;
            this.HasGUI = false;
        }
        public ServiceInfo(string Location, StartMode StartMode)
        {
            this.Name = Path.GetFileName(Location);
            this.Location = Location;
            this.StartMode = StartMode;
            this.IsRunning = false;
            this.HasGUI = false;
        }
    }

}
