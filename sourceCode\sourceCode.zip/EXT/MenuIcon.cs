/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;

using Microsoft.SPOT.Presentation.Media;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.EXT
{

    #region Structures

    internal struct Color32
    {
        public byte A;
        public Color Color;
        public Color32(byte A, Color Color)
        {
            this.A = A;
            this.Color = Color;
        }
        public Color32(Color Color)
        {
            this.A = 255;
            this.Color = Color;
        }
    }

    #endregion

    public class MenuIcon
    {

        #region Variables

        private Color32[][] pixels;
        private int _w;
        private int _h;

        #endregion

        #region Constructor

        public MenuIcon(byte[] bytes)
        {
            int x, y;
            long l;

            if (bytes[0] != 80 || bytes[1] != 50 || bytes[2] != 73)
                throw new Exception("Invalid image Format");

            _w = bytesToInt(bytes[3], bytes[4], bytes[5], bytes[6]);
            _h = bytesToInt(bytes[7], bytes[8], bytes[9], bytes[10]);
            pixels = new Color32[_w][];
            for (int i = 0; i < _w; i++)
            {
                pixels[i] = new Color32[_h];
            }

            l = 11;
            for (y = 0; y < _h; y++)
            {
                for (x = 0; x < _w; x++)
                {
                    pixels[x][y] = new Color32(bytes[l], ColorUtility.ColorFromRGB(bytes[l + 1], bytes[l + 2], bytes[l + 3]));
                    l += 4;
                }
            }

        }

        #endregion

        #region Public Methods

        public void draw(Bitmap bmp, int x, int y)
        {
            int xx, yy;
            Color32 col;

            for (yy = 0; yy < _h; yy++)
            {
                for (xx = 0; xx < _w; xx++)
                {
                    col = pixels[xx][yy];
                    bmp.DrawRectangle(Color.Black, 0, x + xx, y + yy, 1, 1, 0, 0, col.Color, 0, 0, col.Color, 0, 0, col.A);
                }
            }

        }

        #endregion

        #region Private Methods

        private int bytesToInt(byte b1, byte b2, byte b3, byte b4)
        {
            return ((b4 & 0xFF) << 24) + ((b3 & 0xFF) << 16) + ((b2 & 0xFF) << 8) + (b1 & 0xFF);
        }

        #endregion

    }

}
