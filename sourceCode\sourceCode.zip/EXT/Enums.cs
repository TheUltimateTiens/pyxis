/*
Pyxis 2.0
Copyright 2010-2011 Thomas W. Holtquist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

using System;
using Microsoft.SPOT;

namespace Skewworks.Pyxis
{

    public enum DeviceType
    {
        Emulator = 0,
        Cobra = 1,
        ChipworkX = 2,
        Unknown = 99,
    }

    public enum ScreenCalibration
    {
        None = 0,
        Gather = 1,
        Restore = 2,
    }

    public enum NetworkConnectionType
    {
        None = 0,
        DHCP = 1,
        StaticIP = 2,
    }

    public enum PyxisButton
    {
        Up = 0,
        Right = 1,
        Down = 2,
        Left = 3,
        Select = 4,
        Unknown = 255,
    }

    public enum ButtonState
    {
        Down = 0,
        Up = 1,
    }

    public enum ScaleMode
    {
        Normal = 0,
        Stretch = 1,
        Scale = 2,
        Center = 3,
        Tile = 4,
    }

    public enum BorderStyle
    {
        Border3D = 0,
        BorderFlat = 1,
        BorderNone = 2
    }

    public enum PressedState
    {
        Normal = 0,
        Pressed = 1,
    }

    public enum PromptType
    {
        OKOnly = 0,
        OKCancel = 1,
        YesNo = 2,
        YesNoCancel = 3,
    }

    public enum PromptResult
    {
        OK = 0,
        Cancel = 1,
        Yes = 2,
        No = 3,
    }

    public enum Orientation
    {
        Horizontal = 0,
        Vertical = 1,
    }

    public enum TapState
    {
        Normal = 0,
        THWaiting = 1,
        THComplete = 2,
    }

    public enum StartMode
    {
        Manual = 0,
        Automatic = 1,
        Disabled = 2,
    }

}
