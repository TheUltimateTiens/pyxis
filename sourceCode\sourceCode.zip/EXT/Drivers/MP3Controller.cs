//---------------------------------------------------------------------------
//                       GHI Electronics, LLC
//                   http://www.ghielectronics.com
//                        Copyright (c) 2010
//                        All rights reserved
//                          EMX Demo V1.01
//---------------------------------------------------------------------------
/*
 * You can use this file if you agree to the following:
 *
 * 1. This header can't be changed under any condition.
 * 2. This is a free software and therefore is provided with NO warranty.
 * 3. Feel free to modify the code but we ask you to provide us with
 *	  any bug reports so we can keep the code up to date.
 * 4. This code may ONLY be used with GHI Electronics, LLC products.
 *
 * THIS SOFTWARE IS PROVIDED BY GHI ELECTRONICS, LLC ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL 
 * GHI ELECTRONICS, LLC BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR ORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
 *
 *	Specs are subject to change without any notice
 */

using System;
using System.IO;
using System.Threading;
using Microsoft.SPOT;

namespace Skewworks.Pyxis.Drivers
{
    public static class MP3Control
    {
        private static Thread _thread = null;
        private static bool _done;
        private static FileStream _file;
        private static object _source;
        private static byte[] _buffer = new byte[2 * 1024];

        public static void SetSource(object source)
        {
            _source = source;
        }

        public static void Play()
        {
            Stop();
            if (!VS1053.Initialized)
                VS1053.Initialize();

            _done = false;
            _thread = new Thread(Loop);
            _thread.Start();
        }

        public static void Stop()
        {
            _done = true;
            //VS1053.Shutdown();
        }

        private static void Loop()
        {

            _file = File.Open((string)_source, FileMode.Open, FileAccess.Read);
            int count = _file.Read(_buffer, 0, _buffer.Length);

            while (count > 0 && !_done)
            {
                VS1053.SendData(_buffer);
                count = _file.Read(_buffer, 0, _buffer.Length);
            }
            _file.Close();

        }

        public static bool InUse()
        {
            if (_thread == null) return false;
            return _thread.IsAlive;
        }
    }
}
